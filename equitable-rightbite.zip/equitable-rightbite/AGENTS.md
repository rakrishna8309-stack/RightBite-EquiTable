## Project Architecture & Rules
- **Dual-Portal Structure:**
  - `/` — Landing portal chooser (`RightBite` consumer mode vs. `EquiTable` business/pantry operations mode).
  - `/rightbite` — Consumer-facing personal dietary & hidden-ingredient guide with granular restriction selectors and verified web sources.
  - `/equitable`, `/intake`, `/packing`, `/profiles` — High-efficiency business/pantry operational workstation.
- **Deterministic Safety Engine:** All dietary safety verdicts go through `src/lib/equitable/engine.ts` (covered by `src/lib/equitable/engine.test.ts`). UI never re-implements matching logic.
- **Standalone State:** App state lives in `src/lib/equitable/store.tsx` (`EquiTableProvider`) backed by `localStorage` so the app runs cleanly anywhere with zero vendor lock-in.
