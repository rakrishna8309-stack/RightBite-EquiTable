# EquiTable / RightBite roadmap

## Open
- [ ] Persistent storage (Lovable Cloud): inventory, family profiles, packed boxes, slips survive reload
- [ ] Analytics: label scans, allergen flags, items packed, completed packing slips
- [ ] AI ingredient review (AI Gateway): paste text -> possible allergens, dietary concerns, ambiguous ingredients
- [ ] Upload brief #1: receipt-style packing slip modal (header, family ID, timestamp, verified items, exclusion badges, simulated QR, volunteer sign-off)
- [ ] Upload brief #2: "View Impact & Data Story" drawer on dashboard (stacked bar usability, donut secondary interceptions)
- [ ] Upload brief #3: live ingredient text analysis with color badges (red secondary, amber binders, green safe)
- [ ] Upload brief #4: Responsible AI model card (3 guardrails)
- [ ] Upload brief #5: header/footer "EquiTable — Built for MCF AI Bootcamp by Ramakrishna Krishna & Brandon Chae"
- [ ] RightBite: consumer side, app opens to a chooser (RightBite vs EquiTable)
- [ ] RightBite: very granular selector of allergies, intolerances, diets
- [ ] RightBite: "what can I eat" for combined restrictions, with web sources
- [ ] RightBite: explain little-known hidden ingredients (e.g. animal rennet in cheese chips)
- [ ] RightBite friendly look; EquiTable denser/efficient look

## Done
