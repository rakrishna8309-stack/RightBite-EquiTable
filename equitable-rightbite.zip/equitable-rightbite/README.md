# RightBite × EquiTable

Dual-sided dietary intelligence platform created by **Ramakrishna Krishna** and **Brandon Chae**.

- **RightBite (`/rightbite`) — Consumer & Client Side:** Friendly, accessible guide where everyday people select exact combinations of Top-9 allergens, non-regulated allergens (lupin, mustard, sulfites, seeds), food intolerances, and diets (vegetarian, vegan, halal, kosher, low-sugar) to see what they can eat—backed by cited web sources and plain-English breakdowns of hidden ingredients like **animal rennet** in cheese chips.
- **EquiTable (`/equitable`) — Business & Pantry Side:** High-efficiency operational interface for food pantries, schools, and commercial kitchens to scan labels, catch hidden allergens, manage zero-PII client profiles, and pack 100%-compliant food boxes.

## Running Locally

```bash
npm install   # or bun install
npm run test  # run deterministic engine & routing tests
npm run dev   # start dev server on http://localhost:3000
```
