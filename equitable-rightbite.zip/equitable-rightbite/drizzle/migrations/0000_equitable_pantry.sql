
CREATE TABLE public.inventory_items (
  id text PRIMARY KEY DEFAULT gen_random_uuid()::text,
  name text NOT NULL,
  brand text NOT NULL DEFAULT 'Unbranded',
  category text NOT NULL DEFAULT 'General',
  quantity integer NOT NULL DEFAULT 0 CHECK (quantity >= 0),
  allergens text[] NOT NULL DEFAULT '{}',
  may_contain text[] NOT NULL DEFAULT '{}',
  gluten boolean NOT NULL DEFAULT false,
  gelatin boolean NOT NULL DEFAULT false,
  meat boolean NOT NULL DEFAULT false,
  pork boolean NOT NULL DEFAULT false,
  sugar_g numeric NOT NULL DEFAULT 0,
  halal_certified boolean NOT NULL DEFAULT false,
  kosher_certified boolean NOT NULL DEFAULT false,
  ingredients text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.inventory_items TO authenticated;
GRANT ALL ON public.inventory_items TO service_role;
ALTER TABLE public.inventory_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Staff manage inventory" ON public.inventory_items FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE TABLE public.family_profiles (
  id text PRIMARY KEY DEFAULT gen_random_uuid()::text,
  code text NOT NULL UNIQUE,
  summary text NOT NULL DEFAULT '',
  household_size integer NOT NULL DEFAULT 1 CHECK (household_size > 0),
  severity text NOT NULL DEFAULT 'moderate' CHECK (severity IN ('severe','moderate','mild')),
  allergens text[] NOT NULL DEFAULT '{}',
  conditions text[] NOT NULL DEFAULT '{}',
  religious text[] NOT NULL DEFAULT '{}',
  notes text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','packed','picked-up')),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.family_profiles TO authenticated;
GRANT ALL ON public.family_profiles TO service_role;
ALTER TABLE public.family_profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Staff manage families" ON public.family_profiles FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE TABLE public.box_lines (
  profile_id text NOT NULL REFERENCES public.family_profiles(id) ON DELETE CASCADE,
  item_id text NOT NULL REFERENCES public.inventory_items(id) ON DELETE CASCADE,
  name text NOT NULL,
  brand text NOT NULL,
  count integer NOT NULL DEFAULT 1 CHECK (count > 0),
  added_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (profile_id, item_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.box_lines TO authenticated;
GRANT ALL ON public.box_lines TO service_role;
ALTER TABLE public.box_lines ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Staff manage boxes" ON public.box_lines FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE TABLE public.packing_slips (
  id text PRIMARY KEY DEFAULT gen_random_uuid()::text,
  profile_id text,
  profile_code text NOT NULL,
  profile_summary text NOT NULL DEFAULT '',
  lines jsonb NOT NULL DEFAULT '[]',
  safety_score integer NOT NULL DEFAULT 100,
  exclusions text[] NOT NULL DEFAULT '{}',
  volunteer_id uuid,
  packed_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.packing_slips TO authenticated;
GRANT ALL ON public.packing_slips TO service_role;
ALTER TABLE public.packing_slips ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Staff manage slips" ON public.packing_slips FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE TABLE public.activity_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  text text NOT NULL,
  tone text NOT NULL DEFAULT 'info' CHECK (tone IN ('safe','caution','danger','info')),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.activity_log TO authenticated;
GRANT ALL ON public.activity_log TO service_role;
ALTER TABLE public.activity_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Staff manage activity" ON public.activity_log FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE TABLE public.pantry_counters (
  id integer PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  scanned integer NOT NULL DEFAULT 0,
  matched integer NOT NULL DEFAULT 0,
  intercepted integer NOT NULL DEFAULT 0,
  boxes integer NOT NULL DEFAULT 0
);
GRANT SELECT, UPDATE ON public.pantry_counters TO authenticated;
GRANT ALL ON public.pantry_counters TO service_role;
ALTER TABLE public.pantry_counters ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Staff read counters" ON public.pantry_counters FOR SELECT TO authenticated USING (true);
CREATE POLICY "Staff update counters" ON public.pantry_counters FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

-- Atomic operations (run as the calling user, so the policies above still apply)
CREATE OR REPLACE FUNCTION public.pack_item(p_profile text, p_item text)
RETURNS void LANGUAGE plpgsql SECURITY INVOKER SET search_path = public AS $$
DECLARE v_name text; v_brand text;
BEGIN
  UPDATE inventory_items SET quantity = quantity - 1
    WHERE id = p_item AND quantity > 0
    RETURNING name, brand INTO v_name, v_brand;
  IF NOT FOUND THEN RAISE EXCEPTION 'Item is out of stock'; END IF;
  INSERT INTO box_lines (profile_id, item_id, name, brand, count)
    VALUES (p_profile, p_item, v_name, v_brand, 1)
    ON CONFLICT (profile_id, item_id) DO UPDATE SET count = box_lines.count + 1;
END $$;

CREATE OR REPLACE FUNCTION public.unpack_item(p_profile text, p_item text)
RETURNS void LANGUAGE plpgsql SECURITY INVOKER SET search_path = public AS $$
DECLARE v_count integer;
BEGIN
  SELECT count INTO v_count FROM box_lines WHERE profile_id = p_profile AND item_id = p_item FOR UPDATE;
  IF NOT FOUND THEN RETURN; END IF;
  IF v_count > 1 THEN
    UPDATE box_lines SET count = count - 1 WHERE profile_id = p_profile AND item_id = p_item;
  ELSE
    DELETE FROM box_lines WHERE profile_id = p_profile AND item_id = p_item;
  END IF;
  UPDATE inventory_items SET quantity = quantity + 1 WHERE id = p_item;
END $$;

CREATE OR REPLACE FUNCTION public.complete_box(p_profile text, p_score integer, p_exclusions text[])
RETURNS text LANGUAGE plpgsql SECURITY INVOKER SET search_path = public AS $$
DECLARE v_lines jsonb; v_code text; v_summary text; v_slip text;
BEGIN
  SELECT coalesce(jsonb_agg(jsonb_build_object('itemId', item_id, 'name', name, 'brand', brand, 'count', count) ORDER BY added_at), '[]'::jsonb)
    INTO v_lines FROM box_lines WHERE profile_id = p_profile;
  IF jsonb_array_length(v_lines) = 0 THEN RAISE EXCEPTION 'Box is empty'; END IF;
  SELECT code, summary INTO v_code, v_summary FROM family_profiles WHERE id = p_profile;
  INSERT INTO packing_slips (profile_id, profile_code, profile_summary, lines, safety_score, exclusions, volunteer_id)
    VALUES (p_profile, v_code, v_summary, v_lines, p_score, p_exclusions, auth.uid())
    RETURNING id INTO v_slip;
  DELETE FROM box_lines WHERE profile_id = p_profile;
  UPDATE family_profiles SET status = 'packed' WHERE id = p_profile;
  UPDATE pantry_counters SET matched = matched + 1, boxes = boxes + 1 WHERE id = 1;
  INSERT INTO activity_log (text, tone) VALUES ('Box packed for Family #' || v_code || ' — ' || p_score || '% compliant', 'safe');
  RETURN v_slip;
END $$;

CREATE OR REPLACE FUNCTION public.add_scanned_item(
  p_name text, p_brand text, p_category text, p_quantity integer,
  p_allergens text[], p_may_contain text[], p_gluten boolean, p_gelatin boolean,
  p_meat boolean, p_pork boolean, p_sugar_g numeric, p_halal boolean, p_kosher boolean,
  p_ingredients text, p_flagged boolean)
RETURNS text LANGUAGE plpgsql SECURITY INVOKER SET search_path = public AS $$
DECLARE v_id text;
BEGIN
  IF p_quantity < 1 THEN RAISE EXCEPTION 'Quantity must be at least 1'; END IF;
  SELECT id INTO v_id FROM inventory_items WHERE lower(name) = lower(p_name) AND brand = p_brand LIMIT 1;
  IF v_id IS NOT NULL THEN
    UPDATE inventory_items SET quantity = quantity + p_quantity WHERE id = v_id;
  ELSE
    INSERT INTO inventory_items (name, brand, category, quantity, allergens, may_contain, gluten, gelatin, meat, pork, sugar_g, halal_certified, kosher_certified, ingredients)
      VALUES (p_name, p_brand, p_category, p_quantity, p_allergens, p_may_contain, p_gluten, p_gelatin, p_meat, p_pork, p_sugar_g, p_halal, p_kosher, p_ingredients)
      RETURNING id INTO v_id;
  END IF;
  UPDATE pantry_counters SET scanned = scanned + p_quantity,
    intercepted = intercepted + CASE WHEN p_flagged THEN p_quantity ELSE 0 END WHERE id = 1;
  INSERT INTO activity_log (text, tone) VALUES (
    CASE WHEN p_flagged THEN 'Flagged ' || p_quantity || ' × ' || p_name || ' — allergen tags applied'
         ELSE p_quantity || ' × ' || p_name || ' scanned and verified' END,
    CASE WHEN p_flagged THEN 'caution' ELSE 'safe' END);
  RETURN v_id;
END $$;

REVOKE EXECUTE ON FUNCTION public.pack_item(text, text) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.unpack_item(text, text) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.complete_box(text, integer, text[]) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.add_scanned_item(text, text, text, integer, text[], text[], boolean, boolean, boolean, boolean, numeric, boolean, boolean, text, boolean) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.pack_item(text, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.unpack_item(text, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.complete_box(text, integer, text[]) TO authenticated;
GRANT EXECUTE ON FUNCTION public.add_scanned_item(text, text, text, integer, text[], text[], boolean, boolean, boolean, boolean, numeric, boolean, boolean, text, boolean) TO authenticated;

-- Seed data
INSERT INTO public.pantry_counters (id, scanned, matched, intercepted, boxes) VALUES (1, 47, 18, 31, 22);

INSERT INTO public.inventory_items (id, name, brand, category, quantity, allergens, may_contain, gluten, gelatin, meat, pork, sugar_g, halal_certified, kosher_certified, ingredients) VALUES
('inv-01','Rice & Beans Pack','Harvest Table','Grains',24,'{}','{}',false,false,false,false,1,true,false,'White rice, black beans, onion, garlic, cumin, olive oil, sea salt'),
('inv-02','Certified GF Rolled Oats','Prairie Mill','Breakfast',18,'{}','{}',false,false,false,false,1,false,true,'Gluten-free whole grain oats'),
('inv-03','Creamy Peanut Butter','Sunny Acres','Spreads',15,'{peanut}','{}',false,false,false,false,3,false,true,'Roasted peanuts, salt'),
('inv-04','Whole Wheat Penne','Nonna''s','Pasta',30,'{wheat}','{}',true,false,false,false,2,true,true,'Whole durum wheat semolina'),
('inv-05','Fruit Gummy Snacks','Jolly Bites','Snacks',40,'{}','{}',false,true,false,false,18,false,false,'Corn syrup, sugar, gelatin, fruit juice concentrate, citric acid'),
('inv-06','Canned Chickpeas','Greenfield Kitchen','Canned Goods',36,'{}','{}',false,false,false,false,0,true,true,'Chickpeas, water, salt'),
('inv-07','Chunk Light Tuna','Blue Harbor','Protein',22,'{fish}','{}',false,false,false,false,0,false,true,'Light tuna, water, salt'),
('inv-08','Unsweetened Almond Milk','Orchard Pure','Dairy Alternatives',12,'{treenut}','{}',false,false,false,false,0,true,true,'Almond milk (water, almonds), calcium carbonate, sea salt'),
('inv-09','Sesame Rice Crackers','Lotus Road','Snacks',16,'{sesame,soy}','{}',false,false,false,false,2,false,false,'Rice flour, sesame seeds, soy sauce (soybeans, salt)'),
('inv-10','Halal Chicken Breast (Canned)','Crescent Farms','Protein',14,'{}','{}',false,false,true,false,0,true,false,'Chicken breast, water, salt'),
('inv-11','Red Lentils','Prairie Mill','Grains',28,'{}','{}',false,false,false,false,1,true,true,'Red lentils'),
('inv-12','Unsweetened Applesauce','Orchard Pure','Fruit',26,'{}','{}',false,false,false,false,9,true,true,'Apples, water, ascorbic acid'),
('inv-13','Marshmallow Crisp Cereal','Morning Star','Breakfast',10,'{wheat}','{}',true,true,false,false,16,false,false,'Wheat flour, sugar, marshmallows (sugar, corn syrup, gelatin)'),
('inv-14','Granola Clusters','TrailFuel','Breakfast',11,'{treenut}','{peanut,lupin}',true,false,false,false,12,false,false,'Oats, honey, almonds, barley malt. May contain peanut, lupin'),
('inv-15','Brown Basmati Rice','Harvest Table','Grains',20,'{}','{}',false,false,false,false,0,true,true,'Brown basmati rice'),
('inv-16','Low-Sodium Black Beans','Greenfield Kitchen','Canned Goods',32,'{}','{}',false,false,false,false,0,true,true,'Black beans, water, sea salt'),
('inv-17','Dijon Vinaigrette','Maison Claire','Condiments',8,'{mustard,sulfites}','{}',false,false,false,false,3,false,false,'Water, vinegar, mustard seed, white wine (sulfites), oil'),
('inv-18','Shelf-Stable Whole Milk','Valley Dairy','Dairy',9,'{milk}','{}',false,false,false,false,12,true,true,'Whole milk, vitamin D3');

INSERT INTO public.family_profiles (id, code, summary, household_size, severity, allergens, conditions, religious, notes, status, created_at) VALUES
('fam-1042','1042','Severe Peanut Anaphylaxis & Celiac',4,'severe','{peanut}','{celiac}','{}','Child carries epinephrine. Strict no cross-contact.','pending', now() - interval '7 minutes'),
('fam-2089','2089','Halal & Dairy Sensitivity',6,'moderate','{milk}','{}','{halal}','Prefers rice and legumes.','pending', now() - interval '6 minutes'),
('fam-3317','3317','Severe Celiac & Lupin Allergy',3,'severe','{lupin}','{celiac}','{}','Lupin reaction confirmed by allergist.','pending', now() - interval '5 minutes'),
('fam-4120','4120','Kosher & Shellfish Allergy',5,'moderate','{shellfish}','{}','{kosher}','','packed', now() - interval '4 minutes'),
('fam-5204','5204','Diabetes & Vegetarian',2,'mild','{}','{diabetes}','{vegetarian}','Senior household, low sugar items preferred.','pending', now() - interval '3 minutes'),
('fam-6011','6011','Severe Celiac, Lupin & Mustard',4,'severe','{lupin,mustard}','{celiac}','{}','','pending', now() - interval '2 minutes'),
('fam-7356','7356','Tree Nut, Sesame & Halal',7,'moderate','{treenut,sesame}','{}','{halal}','','picked-up', now() - interval '1 minute');

INSERT INTO public.activity_log (text, tone, created_at) VALUES
('New profile added: Family #6011','info', now() - interval '2 hours'),
('24 × Rice & Beans Pack scanned and tagged Halal','safe', now() - interval '80 minutes'),
('Rejected Fruit Gummy Snacks for Halal family — hidden gelatin','danger', now() - interval '45 minutes'),
('Box packed for Family #4120 — 100% compliant','safe', now() - interval '25 minutes'),
('Intercepted Granola Clusters — may contain Lupin','caution', now() - interval '5 minutes');
