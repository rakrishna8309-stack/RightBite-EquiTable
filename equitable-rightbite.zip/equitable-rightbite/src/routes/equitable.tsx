import { Link, createFileRoute, useNavigate } from "@tanstack/react-router";
import {
  AlertOctagon,
  ArrowRight,
  BadgeCheck,
  Boxes,
  Clock,
  PackagePlus,
  ScanLine,
  ShieldAlert,
  ShieldCheck,
  UserPlus,
  Users,
} from "lucide-react";

import { Panel } from "@/components/equitable/AppShell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { isFlagged } from "@/lib/equitable/engine";
import { useEquiTable } from "@/lib/equitable/store";
import type { Tone } from "@/lib/equitable/types";

export const Route = createFileRoute("/equitable")({
  head: () => ({
    meta: [
      { title: "Dashboard — EquiTable Dietary Matching" },
      {
        name: "description",
        content:
          "Live overview of donations scanned, families matched, allergens intercepted and safe boxes packed at your pantry.",
      },
      { property: "og:title", content: "EquiTable Dashboard" },
      {
        property: "og:description",
        content: "Live pantry overview: scans, matches, intercepted allergens and safe boxes.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Dashboard,
});

const toneDot: Record<Tone, string> = {
  safe: "bg-safe",
  caution: "bg-caution",
  danger: "bg-danger",
  info: "bg-info",
};

function Dashboard() {
  const { state, dispatch } = useEquiTable();
  const navigate = useNavigate();
  const { metrics, profiles, inventory, activity } = state;

  const pending = profiles.filter((p) => p.status === "pending");
  const highPriority = pending.filter(
    (p) =>
      p.severity === "severe" && (p.conditions.includes("celiac") || p.allergens.includes("lupin")),
  );
  const flaggedStock = inventory.filter(isFlagged).reduce((n, i) => n + i.quantity, 0);
  const totalStock = inventory.reduce((n, i) => n + i.quantity, 0);
  const safeShare = totalStock ? Math.round(((totalStock - flaggedStock) / totalStock) * 100) : 0;

  const packNext = () => {
    const next = highPriority[0] ?? pending[0];
    if (next) dispatch({ type: "selectProfile", id: next.id });
    navigate({ to: "/packing" });
  };

  const cards = [
    {
      label: "Total Donations Scanned Today",
      value: metrics.scanned,
      note: `${inventory.length} unique products in stock`,
      icon: ScanLine,
      tone: "info" as const,
    },
    {
      label: "Families Matched",
      value: metrics.matched,
      note: `${pending.length} awaiting a box`,
      icon: Users,
      tone: "safe" as const,
    },
    {
      label: "Unsafe Allergen Items Intercepted",
      value: metrics.intercepted,
      note: "60–80% waste reduction vs. manual sorting",
      icon: ShieldAlert,
      tone: "danger" as const,
    },
    {
      label: "Verified Safe Boxes Packed",
      value: metrics.boxes,
      note: "100% rule-engine compliant",
      icon: BadgeCheck,
      tone: "safe" as const,
    },
  ];

  const iconTone: Record<Tone, string> = {
    safe: "bg-safe-soft text-safe-foreground",
    danger: "bg-danger-soft text-danger-foreground",
    info: "bg-info-soft text-info-foreground",
    caution: "bg-caution-soft text-caution-foreground",
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <section className="relative overflow-hidden rounded-3xl bg-hero-gradient p-6 text-on-strong shadow-lift sm:p-10 animate-rise">
        <div className="pointer-events-none absolute inset-0 dot-grid" aria-hidden />
        <div className="relative flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-2xl">
            <Badge variant="safe" className="mb-4 gap-1.5">
              <ShieldCheck className="size-3.5" aria-hidden /> Deterministic safety engine online
            </Badge>
            <h1 className="text-4xl font-extrabold sm:text-6xl">EquiTable</h1>
            <p className="mt-2 font-display text-xl font-medium text-sidebar-primary sm:text-2xl">
              AI-Powered Dietary Matching System
            </p>
            <p className="mt-4 max-w-xl text-sm text-on-strong/75 sm:text-base">
              Sort donations, catch hidden allergens and pack boxes every family can trust — without
              storing a single name.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="hero" size="lg" asChild>
              <Link to="/intake">
                <ScanLine /> Scan New Item
              </Link>
            </Button>
            <Button variant="heroGhost" size="lg" onClick={packNext}>
              <PackagePlus /> Pack Next Box
            </Button>
            <Button variant="heroGhost" size="lg" asChild>
              <Link to="/profiles">
                <UserPlus /> Add Family Profile
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Alerts */}
      {highPriority.length > 0 && (
        <div
          role="alert"
          className="flex flex-col gap-3 rounded-2xl border-2 border-danger/40 bg-danger-soft p-4 sm:flex-row sm:items-center sm:p-5 animate-rise"
        >
          <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-danger text-on-strong">
            <AlertOctagon className="size-6" aria-hidden />
          </span>
          <div className="flex-1">
            <p className="font-display text-lg font-bold text-danger-foreground">
              {highPriority.length} {highPriority.length === 1 ? "Family" : "Families"} with severe
              Celiac &amp; Lupin allergies pending pickup
            </p>
            <p className="text-sm text-danger-foreground/80">
              {highPriority.map((p) => `#${p.code}`).join(", ")} — pack these first with zero
              cross-contact items.
            </p>
          </div>
          <Button variant="danger" onClick={packNext}>
            Pack now <ArrowRight />
          </Button>
        </div>
      )}

      {/* Metrics */}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {cards.map(({ label, value, note, icon: Icon, tone }, i) => (
          <div
            key={label}
            className="rounded-2xl border bg-card p-5 shadow-card animate-rise"
            style={{ animationDelay: `${i * 60}ms` }}
          >
            <div className="flex items-start justify-between gap-3">
              <p className="text-sm font-medium text-muted-foreground">{label}</p>
              <span className={`grid size-9 shrink-0 place-items-center rounded-lg ${iconTone[tone]}`}>
                <Icon className="size-[18px]" aria-hidden />
              </span>
            </div>
            <p className="mt-3 font-display text-4xl font-bold tabular-nums">{value}</p>
            <p className="mt-1 text-xs text-muted-foreground">{note}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <Panel
          title="Families pending pickup"
          icon={<Clock className="size-4 text-primary" aria-hidden />}
          action={
            <Link to="/profiles" className="text-sm font-medium text-primary hover:underline">
              All profiles
            </Link>
          }
        >
          {pending.length === 0 ? (
            <p className="text-sm text-muted-foreground">Every family has a box. Great work!</p>
          ) : (
            <ul className="divide-y">
              {pending.map((p) => (
                <li key={p.id} className="flex items-center gap-3 py-3 first:pt-0 last:pb-0">
                  <span className="font-mono text-sm font-semibold text-muted-foreground">#{p.code}</span>
                  <span className="flex-1 text-sm font-medium">{p.summary}</span>
                  <Badge variant={p.severity === "severe" ? "danger" : p.severity === "moderate" ? "caution" : "info"}>
                    {p.severity}
                  </Badge>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      dispatch({ type: "selectProfile", id: p.id });
                      navigate({ to: "/packing" });
                    }}
                    aria-label={`Pack box for family ${p.code}`}
                  >
                    Pack
                  </Button>
                </li>
              ))}
            </ul>
          )}
        </Panel>

        <div className="space-y-6">
          <Panel title="Stock safety" icon={<Boxes className="size-4 text-primary" aria-hidden />}>
            <div className="flex items-end justify-between">
              <div>
                <p className="font-display text-3xl font-bold">{safeShare}%</p>
                <p className="text-xs text-muted-foreground">of {totalStock} units carry no allergen flag</p>
              </div>
              <Badge variant="caution">{flaggedStock} flagged units</Badge>
            </div>
            <div className="mt-4 flex h-3 overflow-hidden rounded-full bg-muted" aria-hidden>
              <div className="bg-safe" style={{ width: `${safeShare}%` }} />
              <div className="bg-caution" style={{ width: `${100 - safeShare}%` }} />
            </div>
          </Panel>

          <Panel title="Recent activity">
            <ul className="space-y-3" aria-live="polite">
              {activity.slice(0, 6).map((a) => (
                <li key={a.id} className="flex gap-3 text-sm">
                  <span className={`mt-1.5 size-2 shrink-0 rounded-full ${toneDot[a.tone]}`} aria-hidden />
                  <span className="flex-1">{a.text}</span>
                  <span className="shrink-0 text-xs text-muted-foreground">{a.time}</span>
                </li>
              ))}
            </ul>
          </Panel>
        </div>
      </div>
    </div>
  );
}
