import { Link, createFileRoute } from "@tanstack/react-router";
import {
  ArrowRight,
  Building2,
  CheckCircle2,
  HeartHandshake,
  ScanSearch,
  ShieldCheck,
  Sparkles,
} from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Choose Your Experience — RightBite or EquiTable" },
      {
        name: "description",
        content:
          "Open RightBite for everyday personal allergy and ingredient guidance, or EquiTable for business, school, and food pantry operations.",
      },
    ],
  }),
  component: PortalChooser,
});

function PortalChooser() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="border-b bg-card/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4 sm:px-6">
          <div className="flex items-center gap-2.5">
            <span className="grid size-9 place-items-center rounded-xl bg-brand-gradient text-on-strong shadow-card">
              <ShieldCheck className="size-5" aria-hidden />
            </span>
            <div>
              <span className="font-display text-lg font-bold tracking-tight">
                RightBite <span className="text-muted-foreground font-normal">×</span> EquiTable
              </span>
              <span className="block text-[11px] text-muted-foreground">
                Dietary Intelligence for People &amp; Organizations
              </span>
            </div>
          </div>
          <Badge variant="safe" className="hidden sm:inline-flex gap-1">
            <Sparkles className="size-3" aria-hidden /> Deterministic + Source-Verified
          </Badge>
        </div>
      </header>

      <main className="mx-auto flex w-full max-w-6xl flex-1 flex-col justify-center px-4 py-12 sm:px-6">
        <div className="mx-auto max-w-2xl text-center animate-rise">
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-primary">
            Select Your Side
          </p>
          <h1 className="mt-2 font-display text-4xl font-extrabold tracking-tight sm:text-5xl">
            One safety engine. Two tailored experiences.
          </h1>
          <p className="mt-3 text-base text-muted-foreground sm:text-lg">
            Whether you are shopping for yourself or managing food safety for hundreds of families,
            pick the workspace designed for you.
          </p>
        </div>

        <div className="mt-10 grid gap-6 lg:grid-cols-2">
          {/* Consumer / Client Card: RightBite */}
          <section className="group relative flex flex-col justify-between rounded-3xl border-2 border-primary/25 bg-card p-7 shadow-card transition-all hover:border-primary hover:shadow-lift sm:p-9 animate-rise">
            <div>
              <div className="flex items-center justify-between gap-2">
                <Badge variant="safe" className="gap-1.5 px-3 py-1 text-xs">
                  <HeartHandshake className="size-3.5" aria-hidden /> For Everyday People &amp; Shoppers
                </Badge>
                <span className="text-xs font-medium text-muted-foreground">Client Side</span>
              </div>

              <h2 className="mt-5 font-display text-3xl font-extrabold text-foreground sm:text-4xl">
                RightBite
              </h2>
              <p className="mt-2 text-base text-muted-foreground">
                Friendly, plain-English ingredient decoder and personal meal finder. Combine any
                allergies, intolerances, and diets to see what you can safely eat—with cited web
                sources.
              </p>

              <ul className="mt-6 space-y-3 text-sm">
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-safe" aria-hidden />
                  <span>
                    <strong>Granular Multi-Select Filters:</strong> Top-9 allergens, secondary
                    triggers (lupin, mustard, sulfites), intolerances, and religious/ethical diets.
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-safe" aria-hidden />
                  <span>
                    <strong>Hidden Ingredient Spotlights:</strong> Exposes non-obvious additives
                    like <em>animal rennet</em> in cheese chips, carmine (E120), and L-cysteine.
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-safe" aria-hidden />
                  <span>
                    <strong>Source-Backed Answers:</strong> Every recommendation links directly to
                    FDA, Vegetarian Society, and allergy organizations.
                  </span>
                </li>
              </ul>
            </div>

            <div className="mt-8 pt-4">
              <Button size="lg" className="w-full text-base h-12 rounded-xl" asChild>
                <Link to="/rightbite">
                  Open RightBite <ArrowRight className="ml-1 size-4" />
                </Link>
              </Button>
            </div>
          </section>

          {/* Business / Operations Card: EquiTable */}
          <section
            className="group relative flex flex-col justify-between rounded-3xl border border-sidebar-border bg-sidebar p-7 text-sidebar-foreground shadow-card transition-all hover:shadow-lift sm:p-9 animate-rise"
            style={{ animationDelay: "80ms" }}
          >
            <div>
              <div className="flex items-center justify-between gap-2">
                <Badge variant="info" className="gap-1.5 px-3 py-1 text-xs">
                  <Building2 className="size-3.5" aria-hidden /> For Pantries, Schools &amp; Businesses
                </Badge>
                <span className="font-mono text-xs text-sidebar-muted">B2B / OPS MODE</span>
              </div>

              <h2 className="mt-5 font-display text-3xl font-extrabold text-sidebar-foreground sm:text-4xl">
                EquiTable
              </h2>
              <p className="mt-2 text-base text-sidebar-muted">
                High-efficiency operational workstation for emergency food pantries, school
                cafeterias, and commercial kitchens to audit inventory and pack verified-safe boxes.
              </p>

              <ul className="mt-6 space-y-3 text-sm text-sidebar-foreground/90">
                <li className="flex items-start gap-2.5">
                  <ScanSearch className="mt-0.5 size-4 shrink-0 text-sidebar-primary" aria-hidden />
                  <span>
                    <strong>Batch Intake &amp; Label OCR:</strong> Rapidly scan donated stock and
                    flag secondary allergens before items hit shelves.
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <ShieldCheck className="mt-0.5 size-4 shrink-0 text-sidebar-primary" aria-hidden />
                  <span>
                    <strong>Deterministic Box-Packing Station:</strong> Hard-blocks unsafe items
                    against anonymized family profiles and prints compliant slips.
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-sidebar-primary" aria-hidden />
                  <span>
                    <strong>Zero-PII Compliance:</strong> Tracks households strictly by anonymous
                    numeric IDs.
                  </span>
                </li>
              </ul>
            </div>

            <div className="mt-8 pt-4">
              <Button variant="hero" size="lg" className="w-full text-base h-12 rounded-xl" asChild>
                <Link to="/equitable">
                  Launch EquiTable Ops <ArrowRight className="ml-1 size-4" />
                </Link>
              </Button>
            </div>
          </section>
        </div>
      </main>

      <footer className="border-t px-4 py-5 text-center text-xs text-muted-foreground">
        RightBite &amp; EquiTable · Created by Ramakrishna Krishna and Brandon Chae
      </footer>
    </div>
  );
}
