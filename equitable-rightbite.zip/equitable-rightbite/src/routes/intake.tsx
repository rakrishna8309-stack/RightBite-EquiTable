import { createFileRoute } from "@tanstack/react-router";
import {
  BadgeCheck,
  Camera,
  CheckCircle2,
  FileImage,
  Loader2,
  PackagePlus,
  ScanLine,
  Search,
  Sparkles,
  Upload,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";

import { PageHeader, Panel } from "@/components/equitable/AppShell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { SAMPLE_SCANS } from "@/lib/equitable/data";
import { isFlagged, parseLabel, safetyTags, type ParsedLabel } from "@/lib/equitable/engine";
import { useEquiTable } from "@/lib/equitable/store";
import type { FoodFacts, InventoryItem } from "@/lib/equitable/types";

export const Route = createFileRoute("/intake")({
  head: () => ({
    meta: [
      { title: "Inventory Intake & OCR Label Scanner — EquiTable" },
      {
        name: "description",
        content:
          "Scan donated food labels, break down sub-ingredients and auto-tag hidden allergens like Lupin, Mustard, Sulfites and Gelatin.",
      },
      { property: "og:title", content: "EquiTable Label Scanner" },
      {
        property: "og:description",
        content: "Simulated AI label scanning with deterministic allergen tagging.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: IntakePage,
});

const inputCls =
  "w-full rounded-lg border border-input bg-card px-3 py-2 text-sm shadow-sm focus-visible:outline-2 focus-visible:outline-ring";

const tokenCls: Record<string, string> = {
  top9: "bg-danger-soft text-danger-foreground border-danger/30",
  secondary: "bg-caution-soft text-caution-foreground border-caution/50",
  dietary: "bg-info-soft text-info-foreground border-info/25",
  info: "bg-muted text-muted-foreground border-border",
  clean: "bg-safe-soft/60 text-safe-foreground border-safe/20",
};

interface ScanResult {
  parsed: ParsedLabel;
  facts: FoodFacts;
  confidence: number;
  source: string;
}

function IntakePage() {
  const { state, dispatch } = useEquiTable();
  const [sampleId, setSampleId] = useState<string>("A");
  const [form, setForm] = useState(() => fromSample("A"));
  const [preview, setPreview] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [dragging, setDragging] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState<ScanResult | null>(null);
  const [source, setSource] = useState<{ label: string; confidence: number }>({
    label: SAMPLE_SCANS[0]!.label,
    confidence: SAMPLE_SCANS[0]!.confidence,
  });
  const [query, setQuery] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => () => void (preview && URL.revokeObjectURL(preview)), [preview]);

  function fromSample(id: string) {
    const s = SAMPLE_SCANS.find((x) => x.id === id)!;
    return {
      name: s.name,
      brand: s.brand,
      category: s.category,
      quantity: 12,
      sugarG: s.sugarG,
      halalCertified: s.halalCertified,
      kosherCertified: s.kosherCertified,
      ingredients: s.ingredients,
    };
  }

  const loadSample = (id: string) => {
    setSampleId(id);
    setForm(fromSample(id));
    const s = SAMPLE_SCANS.find((x) => x.id === id)!;
    setSource({ label: s.label, confidence: s.confidence });
    setPreview(null);
    setFileName(null);
    runScan(fromSample(id).ingredients, fromSample(id), { label: s.label, confidence: s.confidence });
  };

  const handleFile = (file: File | undefined) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast.error("Please upload a photo of the ingredient label (JPG or PNG).");
      return;
    }
    setPreview(URL.createObjectURL(file));
    setFileName(file.name);
    // Simulated OCR: deterministically maps the photo to one of the sample label texts.
    const s = SAMPLE_SCANS[file.size % SAMPLE_SCANS.length]!;
    const next = { ...fromSample(s.id), name: s.name };
    setSampleId(s.id);
    setForm(next);
    const src = { label: `Photo upload: ${file.name}`, confidence: 94.6 };
    setSource(src);
    runScan(next.ingredients, next, src);
  };

  function runScan(text: string, f = form, src = source) {
    if (!text.trim()) {
      toast.error("Add ingredient text or upload a label photo first.");
      return;
    }
    setScanning(true);
    setResult(null);
    window.setTimeout(() => {
      const parsed = parseLabel(text);
      const facts: FoodFacts = {
        allergens: parsed.allergens,
        mayContain: parsed.mayContain,
        gluten: parsed.gluten,
        gelatin: parsed.gelatin,
        meat: parsed.meat,
        pork: parsed.pork,
        sugarG: Number(f.sugarG) || 0,
        halalCertified: f.halalCertified,
        kosherCertified: f.kosherCertified,
      };
      setResult({ parsed, facts, confidence: src.confidence, source: src.label });
      setScanning(false);
    }, 1300);
  }

  const addToInventory = () => {
    if (!result) return;
    if (!form.name.trim()) {
      toast.error("Give the product a name before adding it.");
      return;
    }
    const item: InventoryItem = {
      ...result.facts,
      id: `inv-${Date.now()}`,
      name: form.name.trim(),
      brand: form.brand.trim() || "Unbranded",
      category: form.category.trim() || "General",
      quantity: Math.max(1, Number(form.quantity) || 1),
      ingredients: form.ingredients,
    };
    const flagged = isFlagged(item);
    dispatch({ type: "addScanned", item, flagged });
    toast.success(`${item.quantity} × ${item.name} added to inventory`, {
      description: flagged ? "Allergen flags applied — unsafe for matching families." : "Verified safe tags applied.",
    });
    setResult(null);
  };

  const tags = result ? safetyTags(result.facts) : [];
  const flaggedTokens = result?.parsed.tokens.filter((t) => t.kind === "top9" || t.kind === "secondary") ?? [];

  const filtered = useMemo(
    () =>
      state.inventory.filter((i) =>
        `${i.name} ${i.brand} ${i.category}`.toLowerCase().includes(query.toLowerCase()),
      ),
    [state.inventory, query],
  );

  return (
    <div>
      <PageHeader
        eyebrow="Step 1 · Intake"
        title="Inventory Intake & Label Scanner"
        description="Photograph an ingredient label or try a sample. The scanner breaks it into sub-ingredients and the rule engine tags every allergen — including the ones the law doesn't require."
      />

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Input side */}
        <Panel title="Scan a label" icon={<Camera className="size-4 text-primary" aria-hidden />}>
          <div className="space-y-5">
            <div>
              <label htmlFor="sample" className="mb-1.5 block text-sm font-semibold">
                Try Sample Scan
              </label>
              <select
                id="sample"
                value={sampleId}
                onChange={(e) => loadSample(e.target.value)}
                className={inputCls}
              >
                {SAMPLE_SCANS.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.label}
                  </option>
                ))}
              </select>
            </div>

            <div
              onDragOver={(e) => {
                e.preventDefault();
                setDragging(true);
              }}
              onDragLeave={() => setDragging(false)}
              onDrop={(e) => {
                e.preventDefault();
                setDragging(false);
                handleFile(e.dataTransfer.files[0]);
              }}
              className={`relative overflow-hidden rounded-2xl border-2 border-dashed p-6 text-center transition-colors ${
                dragging ? "border-primary bg-accent" : "border-input bg-muted/50"
              }`}
            >
              {preview ? (
                <div className="relative mx-auto aspect-[4/3] max-h-56 overflow-hidden rounded-xl">
                  <img src={preview} alt={`Uploaded label ${fileName ?? ""}`} className="size-full object-cover" />
                  {scanning && (
                    <span className="absolute inset-x-0 h-1 bg-sidebar-primary shadow-lift animate-scan" aria-hidden />
                  )}
                </div>
              ) : (
                <div className="relative py-4">
                  <span className="mx-auto grid size-14 place-items-center rounded-2xl bg-card shadow-card">
                    {scanning ? (
                      <Loader2 className="size-6 animate-spin text-primary" aria-hidden />
                    ) : (
                      <FileImage className="size-6 text-primary" aria-hidden />
                    )}
                  </span>
                  <p className="mt-3 font-semibold">Drop a label photo here</p>
                  <p className="text-sm text-muted-foreground">or use your camera — JPG / PNG</p>
                </div>
              )}
              <div className="mt-4 flex flex-wrap justify-center gap-2">
                <Button type="button" variant="outline" onClick={() => fileRef.current?.click()}>
                  <Upload /> Upload / Take Photo
                </Button>
              </div>
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                capture="environment"
                className="sr-only"
                aria-label="Upload ingredient label photo"
                onChange={(e) => handleFile(e.target.files?.[0])}
              />
            </div>

            <div>
              <label htmlFor="ingredients" className="mb-1.5 block text-sm font-semibold">
                Extracted label text <span className="font-normal text-muted-foreground">(editable)</span>
              </label>
              <textarea
                id="ingredients"
                rows={4}
                value={form.ingredients}
                onChange={(e) => setForm({ ...form, ingredients: e.target.value })}
                className={inputCls}
              />
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Product name" id="name">
                <input id="name" className={inputCls} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              </Field>
              <Field label="Brand" id="brand">
                <input id="brand" className={inputCls} value={form.brand} onChange={(e) => setForm({ ...form, brand: e.target.value })} />
              </Field>
              <Field label="Category" id="category">
                <input id="category" className={inputCls} value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} />
              </Field>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Units" id="qty">
                  <input id="qty" type="number" min={1} className={inputCls} value={form.quantity} onChange={(e) => setForm({ ...form, quantity: Number(e.target.value) })} />
                </Field>
                <Field label="Sugar g/serv." id="sugar">
                  <input id="sugar" type="number" min={0} className={inputCls} value={form.sugarG} onChange={(e) => setForm({ ...form, sugarG: Number(e.target.value) })} />
                </Field>
              </div>
            </div>

            <fieldset className="flex flex-wrap gap-4">
              <legend className="sr-only">Certifications on package</legend>
              {(["halalCertified", "kosherCertified"] as const).map((k) => (
                <label key={k} className="flex items-center gap-2 text-sm font-medium">
                  <input
                    type="checkbox"
                    className="size-4 accent-primary"
                    checked={form[k]}
                    onChange={(e) => setForm({ ...form, [k]: e.target.checked })}
                  />
                  {k === "halalCertified" ? "Halal Certified seal" : "Kosher Certified seal"}
                </label>
              ))}
            </fieldset>

            <Button
              size="lg"
              className="w-full"
              disabled={scanning}
              onClick={() => runScan(form.ingredients)}
            >
              {scanning ? <Loader2 className="animate-spin" /> : <ScanLine />}
              {scanning ? "Scanning label…" : "Run AI Scan"}
            </Button>
          </div>
        </Panel>

        {/* Output side */}
        <Panel
          title="AI Scan Output"
          icon={<Sparkles className="size-4 text-primary" aria-hidden />}
          className="lg:sticky lg:top-6 self-start"
        >
          <div aria-live="polite">
            {!result && !scanning && (
              <div className="grid place-items-center py-16 text-center">
                <ScanLine className="size-10 text-muted-foreground/50" aria-hidden />
                <p className="mt-3 font-medium">No scan yet</p>
                <p className="text-sm text-muted-foreground">Pick a sample or upload a label to begin.</p>
              </div>
            )}
            {scanning && (
              <div className="space-y-3 py-6" role="status">
                <p className="flex items-center gap-2 text-sm font-medium">
                  <Loader2 className="size-4 animate-spin text-primary" aria-hidden /> Reading label &amp; running rule checks…
                </p>
                {[80, 64, 92, 50].map((w) => (
                  <div key={w} className="h-3 animate-pulse rounded bg-muted" style={{ width: `${w}%` }} />
                ))}
              </div>
            )}
            {result && (
              <div className="space-y-5 animate-rise">
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="rounded-xl border bg-muted/40 p-4">
                    <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">AI OCR Confidence</p>
                    <p className="mt-1 font-display text-3xl font-bold tabular-nums">{result.confidence.toFixed(1)}%</p>
                    <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-muted">
                      <div className="h-full bg-primary" style={{ width: `${result.confidence}%` }} />
                    </div>
                    <p className="mt-2 truncate text-xs text-muted-foreground">{result.source}</p>
                  </div>
                  <div className="rounded-xl border-2 border-safe/40 bg-safe-soft p-4 text-safe-foreground">
                    <BadgeCheck className="size-6" aria-hidden />
                    <p className="mt-2 font-display font-bold leading-snug">
                      Deterministic Rule Verified — Zero Hallucination Risk
                    </p>
                    <p className="mt-1 text-xs opacity-80">Allergens are matched by fixed rules, never guessed.</p>
                  </div>
                </div>

                <div>
                  <h3 className="mb-2 text-sm font-semibold">
                    Sub-Ingredient Breakdown{" "}
                    <span className="font-normal text-muted-foreground">
                      · {result.parsed.tokens.length} parts, {flaggedTokens.length} flagged
                    </span>
                  </h3>
                  <ul className="flex flex-wrap gap-1.5">
                    {result.parsed.tokens.map((t, i) => (
                      <li
                        key={i}
                        className={`rounded-md border px-2 py-1 text-xs font-medium ${tokenCls[t.kind]}`}
                        title={t.flags.join(", ") || "No flags"}
                      >
                        {t.text}
                        {t.flags.length > 0 && t.kind !== "info" && (
                          <span className="ml-1 font-bold">⚑ {t.flags.filter((f) => f !== "Added sugar" && f !== "Sodium").join(", ")}</span>
                        )}
                      </li>
                    ))}
                  </ul>
                  <div className="mt-3 flex flex-wrap gap-3 text-[11px] text-muted-foreground">
                    <Legend cls="bg-danger" label="Top 9 allergen" />
                    <Legend cls="bg-caution" label="Secondary / hidden (Lupin, Mustard, Sulfites, Gelatin)" />
                    <Legend cls="bg-info" label="Dietary (gluten, meat)" />
                    <Legend cls="bg-safe" label="Clear" />
                  </div>
                </div>

                <div>
                  <h3 className="mb-2 text-sm font-semibold">Automated Safety Tags</h3>
                  <div className="flex flex-wrap gap-1.5">
                    {tags.map((t) => (
                      <Badge key={t.label} variant={t.tone}>
                        [{t.label}]
                      </Badge>
                    ))}
                  </div>
                </div>

                {!isFlagged(result.facts) && (
                  <p className="flex items-center gap-2 rounded-lg bg-safe-soft p-3 text-sm font-medium text-safe-foreground">
                    <CheckCircle2 className="size-4" aria-hidden /> 100% Top-9 &amp; Secondary Allergen Free
                  </p>
                )}

                <Button size="lg" className="w-full" onClick={addToInventory}>
                  <PackagePlus /> Add {form.quantity} units to Inventory
                </Button>
              </div>
            )}
          </div>
        </Panel>
      </div>

      <Panel
        className="mt-6"
        title={`Pantry stock (${state.inventory.length})`}
        action={
          <div className="relative">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
            <input
              aria-label="Search inventory"
              placeholder="Search stock…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className={`${inputCls} w-48 pl-8 sm:w-64`}
            />
          </div>
        }
      >
        <div className="-mx-5 -my-5 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-left text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th scope="col" className="px-5 py-3">Product</th>
                <th scope="col" className="px-5 py-3">Category</th>
                <th scope="col" className="px-5 py-3 text-right">Units</th>
                <th scope="col" className="px-5 py-3">Safety tags</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {filtered.map((i) => (
                <tr key={i.id} className="align-top">
                  <td className="px-5 py-3">
                    <p className="font-medium">{i.name}</p>
                    <p className="text-xs text-muted-foreground">{i.brand}</p>
                  </td>
                  <td className="px-5 py-3 text-muted-foreground">{i.category}</td>
                  <td className="px-5 py-3 text-right font-mono tabular-nums">{i.quantity}</td>
                  <td className="px-5 py-3">
                    <div className="flex flex-wrap gap-1">
                      {safetyTags(i).map((t) => (
                        <Badge key={t.label} variant={t.tone} className="px-1.5 text-[10px]">
                          {t.label}
                        </Badge>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-5 py-8 text-center text-muted-foreground">
                    No products match “{query}”.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Panel>
    </div>
  );
}

function Field({ label, id, children }: { label: string; id: string; children: React.ReactNode }) {
  return (
    <div>
      <label htmlFor={id} className="mb-1.5 block text-xs font-semibold text-muted-foreground">
        {label}
      </label>
      {children}
    </div>
  );
}

function Legend({ cls, label }: { cls: string; label: string }) {
  return (
    <span className="flex items-center gap-1.5">
      <span className={`size-2 rounded-full ${cls}`} aria-hidden /> {label}
    </span>
  );
}
