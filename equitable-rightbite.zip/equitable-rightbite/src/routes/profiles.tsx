import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Lock, PackagePlus, Search, ShieldCheck, Trash2, UserPlus } from "lucide-react";
import { useMemo, useState, type FormEvent } from "react";
import { toast } from "sonner";

import { PageHeader, Panel } from "@/components/equitable/AppShell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { containsPII, describeProfile, profileRestrictionLabels } from "@/lib/equitable/engine";
import { useEquiTable } from "@/lib/equitable/store";
import {
  ALLERGEN_LABEL,
  CONDITIONS,
  CONDITION_LABEL,
  RELIGIOUS,
  RELIGIOUS_LABEL,
  SECONDARY,
  TOP9,
  type Allergen,
  type Condition,
  type FamilyProfile,
  type Religious,
  type Severity,
} from "@/lib/equitable/types";

export const Route = createFileRoute("/profiles")({
  head: () => ({
    meta: [
      { title: "Anonymized Client Dietary Profiles — EquiTable" },
      {
        name: "description",
        content:
          "Record family allergens, medical conditions and religious requirements by anonymous ID — no personal information stored.",
      },
      { property: "og:title", content: "EquiTable Client Dietary Profiles" },
      {
        property: "og:description",
        content: "Dignity-preserving, PII-free dietary intake for food pantry families.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ProfilesPage,
});

const emptyForm = {
  householdSize: 3,
  severity: "moderate" as Severity,
  allergens: [] as Allergen[],
  conditions: [] as Condition[],
  religious: [] as Religious[],
  notes: "",
};

type FilterKey = "all" | "pending" | "severe" | "celiac" | "halal" | "kosher";
const FILTERS: [FilterKey, string][] = [
  ["all", "All"],
  ["pending", "Pending pickup"],
  ["severe", "Severe"],
  ["celiac", "Celiac"],
  ["halal", "Halal"],
  ["kosher", "Kosher"],
];

function ProfilesPage() {
  const { state, dispatch } = useEquiTable();
  const navigate = useNavigate();
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<FilterKey>("all");

  const toggle = <K extends "allergens" | "conditions" | "religious">(key: K, value: (typeof form)[K][number]) => {
    const list = form[key] as string[];
    setForm({
      ...form,
      [key]: list.includes(value) ? list.filter((v) => v !== value) : [...list, value],
    });
  };

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (containsPII(form.notes)) {
      setError("Notes look like they include personal details (email, phone or address). Please remove them.");
      return;
    }
    if (form.allergens.length + form.conditions.length + form.religious.length === 0) {
      setError("Select at least one restriction or requirement.");
      return;
    }
    const used = new Set(state.profiles.map((p) => p.code));
    let code = "";
    do code = String(1000 + Math.floor(Math.random() * 9000));
    while (used.has(code));
    const profile: FamilyProfile = {
      id: `fam-${code}`,
      code,
      summary: describeProfile(form),
      householdSize: Math.max(1, form.householdSize),
      severity: form.severity,
      allergens: form.allergens,
      conditions: form.conditions,
      religious: form.religious,
      notes: form.notes.trim(),
      status: "pending",
    };
    dispatch({ type: "addProfile", profile });
    setForm(emptyForm);
    setError(null);
    toast.success(`Family #${code} added`, { description: profile.summary });
  };

  const list = useMemo(
    () =>
      state.profiles.filter((p) => {
        const text = `${p.code} ${p.summary}`.toLowerCase();
        if (query && !text.includes(query.toLowerCase())) return false;
        switch (filter) {
          case "pending":
            return p.status === "pending";
          case "severe":
            return p.severity === "severe";
          case "celiac":
            return p.conditions.includes("celiac");
          case "halal":
          case "kosher":
            return p.religious.includes(filter);
          default:
            return true;
        }
      }),
    [state.profiles, query, filter],
  );

  return (
    <div>
      <PageHeader
        eyebrow="Step 3 · Intake"
        title="Client Dietary Profiles"
        description="Families are identified only by an anonymous number. No names, addresses or phone numbers — just what keeps them safe."
      />

      <div className="grid gap-6 lg:grid-cols-[minmax(340px,440px)_1fr]">
        <Panel
          title="New anonymized profile"
          icon={<UserPlus className="size-4 text-primary" aria-hidden />}
          className="self-start"
        >
          <form onSubmit={submit} className="space-y-5" noValidate>
            <div className="flex items-start gap-2 rounded-lg bg-info-soft p-3 text-xs text-info-foreground">
              <Lock className="mt-0.5 size-3.5 shrink-0" aria-hidden />
              A random family ID is generated on save. Never enter names or contact details.
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="hh" className="mb-1.5 block text-xs font-semibold text-muted-foreground">
                  Household size
                </label>
                <input
                  id="hh"
                  type="number"
                  min={1}
                  max={20}
                  value={form.householdSize}
                  onChange={(e) => setForm({ ...form, householdSize: Number(e.target.value) })}
                  className="w-full rounded-lg border border-input bg-card px-3 py-2 text-sm shadow-sm"
                />
              </div>
              <div>
                <label htmlFor="sev" className="mb-1.5 block text-xs font-semibold text-muted-foreground">
                  Reaction severity
                </label>
                <select
                  id="sev"
                  value={form.severity}
                  onChange={(e) => setForm({ ...form, severity: e.target.value as Severity })}
                  className="w-full rounded-lg border border-input bg-card px-3 py-2 text-sm shadow-sm"
                >
                  <option value="severe">Severe / anaphylaxis</option>
                  <option value="moderate">Moderate</option>
                  <option value="mild">Mild / preference</option>
                </select>
              </div>
            </div>

            <CheckGroup
              legend="Top 9 Allergens"
              options={TOP9.map((a) => [a, ALLERGEN_LABEL[a]])}
              selected={form.allergens}
              onToggle={(v) => toggle("allergens", v as Allergen)}
              tone="danger"
            />
            <CheckGroup
              legend="Secondary / Non-Mandated Allergens"
              options={SECONDARY.map((a) => [a, ALLERGEN_LABEL[a]])}
              selected={form.allergens}
              onToggle={(v) => toggle("allergens", v as Allergen)}
              tone="caution"
            />
            <CheckGroup
              legend="Medical Conditions"
              options={CONDITIONS.map((c) => [c, CONDITION_LABEL[c]])}
              selected={form.conditions}
              onToggle={(v) => toggle("conditions", v as Condition)}
              tone="info"
            />
            <CheckGroup
              legend="Religious / Cultural Requirements"
              options={RELIGIOUS.map((r) => [r, RELIGIOUS_LABEL[r]])}
              selected={form.religious}
              onToggle={(v) => toggle("religious", v as Religious)}
              tone="safe"
            />

            <div>
              <label htmlFor="notes" className="mb-1.5 block text-xs font-semibold text-muted-foreground">
                Handling notes <span className="font-normal">(optional, no personal info)</span>
              </label>
              <textarea
                id="notes"
                rows={2}
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
                placeholder="e.g. Child carries epinephrine"
                className="w-full rounded-lg border border-input bg-card px-3 py-2 text-sm shadow-sm"
              />
            </div>

            {error && (
              <p role="alert" className="rounded-lg bg-danger-soft p-3 text-sm font-medium text-danger-foreground">
                {error}
              </p>
            )}

            <Button type="submit" size="lg" className="w-full">
              <ShieldCheck /> Save anonymized profile
            </Button>
          </form>
        </Panel>

        <div className="space-y-4">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
              <input
                aria-label="Search profiles"
                placeholder="Search by family # or restriction…"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="w-full rounded-lg border border-input bg-card py-2.5 pl-9 pr-3 text-sm shadow-sm"
              />
            </div>
          </div>
          <div className="flex flex-wrap gap-1.5" role="group" aria-label="Filter profiles">
            {FILTERS.map(([k, label]) => (
              <button
                key={k}
                type="button"
                aria-pressed={filter === k}
                onClick={() => setFilter(k)}
                className={`rounded-full border px-3 py-1.5 text-xs font-semibold transition-colors ${
                  filter === k ? "border-primary bg-primary text-primary-foreground" : "bg-card text-muted-foreground hover:bg-muted"
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <p className="text-sm text-muted-foreground" aria-live="polite">
            Showing {list.length} of {state.profiles.length} families
          </p>

          <ul className="grid gap-4 md:grid-cols-2 lg:grid-cols-1 2xl:grid-cols-2">
            {list.map((p) => {
              const r = profileRestrictionLabels(p);
              return (
                <li key={p.id} className="flex flex-col rounded-2xl border bg-card p-5 shadow-card animate-rise">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="font-mono text-xs font-semibold text-muted-foreground">FAMILY #{p.code}</p>
                      <h3 className="mt-0.5 font-display text-lg font-bold leading-tight">{p.summary}</h3>
                    </div>
                    <Badge variant={p.severity === "severe" ? "solidDanger" : p.severity === "moderate" ? "caution" : "info"} className="uppercase">
                      {p.severity}
                    </Badge>
                  </div>
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {r.top9.map((x) => <Badge key={x} variant="danger">{x}</Badge>)}
                    {r.secondary.map((x) => <Badge key={x} variant="caution">{x}</Badge>)}
                    {r.conditions.map((x) => <Badge key={x} variant="info">{x}</Badge>)}
                    {r.religious.map((x) => <Badge key={x} variant="safe">{x}</Badge>)}
                  </div>
                  {p.notes && <p className="mt-3 text-xs text-muted-foreground">{p.notes}</p>}
                  <div className="mt-auto flex flex-wrap items-center gap-2 pt-4">
                    <span className="w-full text-xs text-muted-foreground sm:w-auto sm:flex-1">
                      Household of {p.householdSize} ·{" "}
                      <span className={p.status === "pending" ? "font-semibold text-caution-foreground" : "font-semibold text-safe-foreground"}>
                        {p.status === "pending" ? "Pending pickup" : p.status === "packed" ? "Box packed" : "Picked up"}
                      </span>
                    </span>
                    {p.status === "packed" && (
                      <Button size="sm" variant="ghost" onClick={() => dispatch({ type: "markPickedUp", profileId: p.id })}>
                        Mark picked up
                      </Button>
                    )}
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        dispatch({ type: "selectProfile", id: p.id });
                        navigate({ to: "/packing" });
                      }}
                    >
                      <PackagePlus /> Pack
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="size-8 text-muted-foreground hover:text-danger"
                      aria-label={`Delete family ${p.code}`}
                      onClick={() => {
                        dispatch({ type: "removeProfile", id: p.id });
                        toast(`Family #${p.code} removed`);
                      }}
                    >
                      <Trash2 />
                    </Button>
                  </div>
                </li>
              );
            })}
          </ul>
          {list.length === 0 && (
            <Panel>
              <p className="text-center text-sm text-muted-foreground">No families match these filters.</p>
            </Panel>
          )}
        </div>
      </div>
    </div>
  );
}

function CheckGroup({
  legend,
  options,
  selected,
  onToggle,
  tone,
}: {
  legend: string;
  options: [string, string][];
  selected: string[];
  onToggle: (v: string) => void;
  tone: "danger" | "caution" | "info" | "safe";
}) {
  const on: Record<typeof tone, string> = {
    danger: "peer-checked:border-danger peer-checked:bg-danger-soft peer-checked:text-danger-foreground",
    caution: "peer-checked:border-caution peer-checked:bg-caution-soft peer-checked:text-caution-foreground",
    info: "peer-checked:border-info peer-checked:bg-info-soft peer-checked:text-info-foreground",
    safe: "peer-checked:border-safe peer-checked:bg-safe-soft peer-checked:text-safe-foreground",
  };
  return (
    <fieldset>
      <legend className="mb-2 text-sm font-semibold">{legend}</legend>
      <div className="flex flex-wrap gap-2">
        {options.map(([value, label]) => (
          <label key={value} className="cursor-pointer">
            <input
              type="checkbox"
              className="peer sr-only"
              checked={selected.includes(value)}
              onChange={() => onToggle(value)}
            />
            <span
              className={`inline-flex items-center rounded-full border bg-card px-3 py-1.5 text-xs font-semibold text-muted-foreground transition-colors peer-focus-visible:outline-2 peer-focus-visible:outline-offset-2 peer-focus-visible:outline-ring ${on[tone]}`}
            >
              {label}
            </span>
          </label>
        ))}
      </div>
    </fieldset>
  );
}
