import { Link, createFileRoute } from "@tanstack/react-router";
import {
  AlertTriangle,
  ArrowLeftRight,
  BookOpen,
  CheckCircle2,
  ExternalLink,
  HelpCircle,
  Search,
  Sparkles,
  Utensils,
} from "lucide-react";
import { useMemo, useState } from "react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { liveAnalyze } from "@/lib/equitable/engine";
import {
  HIDDEN_INGREDIENTS,
  RESTRICTION_OPTIONS,
  RESTRICTION_SECTIONS,
  buildCombinedGuidance,
} from "@/lib/rightbite/catalog";

export const Route = createFileRoute("/rightbite")({
  head: () => ({
    meta: [
      { title: "RightBite — Personal Allergy, Intolerance & Ingredient Guide" },
      {
        name: "description",
        content:
          "Select your exact allergies, intolerances, and dietary rules to discover safe foods and uncover hidden ingredients like animal rennet.",
      },
    ],
  }),
  component: RightBitePage,
});

const SAMPLE_SNACKS = [
  {
    label: "Nacho Cheese Tortilla Chips",
    ingredients:
      "Corn, vegetable oil, whey, cheddar cheese (milk, cheese cultures, salt, enzymes), buttermilk, maltodextrin, onion powder, natural flavors, yellow 6",
  },
  {
    label: "Gluten-Free Protein Muffin",
    ingredients:
      "Tapioca flour, lupin flour, cane sugar, sunflower oil, pea protein, xanthan gum, baking powder, sea salt",
  },
  {
    label: "Strawberry Fruit Chews",
    ingredients:
      "Corn syrup, sugar, gelatin, citric acid, natural flavor, carmine, carnauba wax",
  },
];

function RightBitePage() {
  const [selectedIds, setSelectedIds] = useState<string[]>(["vegetarian", "treenut"]);
  const [labelText, setLabelText] = useState(SAMPLE_SNACKS[0]!.ingredients);
  const [hiddenSearch, setHiddenSearch] = useState("");

  const toggleRestriction = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id],
    );
  };

  const guidance = useMemo(() => buildCombinedGuidance(selectedIds), [selectedIds]);
  const liveBadges = useMemo(() => liveAnalyze(labelText), [labelText]);

  const hiddenMatchesInLabel = useMemo(() => {
    const lower = labelText.toLowerCase();
    return HIDDEN_INGREDIENTS.filter((entry) =>
      entry.aliases.some((alias) => lower.includes(alias.toLowerCase())),
    );
  }, [labelText]);

  const filteredHiddenGuide = useMemo(
    () =>
      HIDDEN_INGREDIENTS.filter((h) =>
        `${h.name} ${h.aliases.join(" ")} ${h.commonProducts.join(" ")} ${h.affects.join(" ")}`
          .toLowerCase()
          .includes(hiddenSearch.toLowerCase()),
      ),
    [hiddenSearch],
  );

  return (
    <div className="min-h-screen bg-background">
      {/* Friendly Consumer Top Nav */}
      <header className="sticky top-0 z-40 border-b bg-card/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3.5 sm:px-6">
          <Link to="/" className="flex items-center gap-2.5">
            <span className="grid size-9 place-items-center rounded-xl bg-brand-gradient text-on-strong">
              <Utensils className="size-5" aria-hidden />
            </span>
            <div>
              <span className="font-display text-xl font-extrabold tracking-tight">RightBite</span>
              <span className="block text-[11px] text-muted-foreground">
                Eat with confidence · Source-verified
              </span>
            </div>
          </Link>

          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" asChild>
              <Link to="/equitable">
                <ArrowLeftRight className="size-3.5" /> Switch to EquiTable (Business)
              </Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl space-y-10 px-4 py-8 sm:px-6">
        {/* Friendly Welcome Banner */}
        <section className="rounded-3xl border bg-gradient-to-br from-safe-soft via-card to-info-soft p-6 shadow-card sm:p-9 animate-rise">
          <Badge variant="safe" className="mb-3 gap-1.5">
            <Sparkles className="size-3.5" aria-hidden /> Personal Food &amp; Ingredient Guide
          </Badge>
          <h1 className="font-display text-3xl font-extrabold tracking-tight sm:text-5xl">
            Know what is actually in your food.
          </h1>
          <p className="mt-3 max-w-2xl text-base text-muted-foreground sm:text-lg">
            Check every allergy, intolerance, and diet that applies to you—even combinations like{" "}
            <strong className="text-foreground">Vegetarian + Tree Nut Allergy</strong>—and get
            plain-English answers backed by real sources.
          </p>

          {/* Quick Preset Pills */}
          <div className="mt-5 flex flex-wrap items-center gap-2">
            <span className="text-xs font-semibold text-muted-foreground">Try a combo:</span>
            <button
              type="button"
              onClick={() => setSelectedIds(["vegetarian", "treenut", "peanut"])}
              className="rounded-full border bg-card px-3 py-1 text-xs font-semibold hover:border-primary"
            >
              Vegetarian + Nut-Free
            </button>
            <button
              type="button"
              onClick={() => setSelectedIds(["celiac", "lupin", "milk"])}
              className="rounded-full border bg-card px-3 py-1 text-xs font-semibold hover:border-primary"
            >
              Celiac + Lupin + Dairy-Free
            </button>
            <button
              type="button"
              onClick={() => setSelectedIds(["halal", "sesame"])}
              className="rounded-full border bg-card px-3 py-1 text-xs font-semibold hover:border-primary"
            >
              Halal + Sesame-Free
            </button>
            {selectedIds.length > 0 && (
              <button
                type="button"
                onClick={() => setSelectedIds([])}
                className="text-xs font-medium text-muted-foreground underline hover:text-foreground"
              >
                Clear all
              </button>
            )}
          </div>
        </section>

        {/* Step 1: Granular Multi-Section Restriction Selector */}
        <section className="space-y-4">
          <div className="flex flex-wrap items-end justify-between gap-2">
            <div>
              <h2 className="font-display text-2xl font-bold">
                Step 1: Select Your Exact Restrictions
              </h2>
              <p className="text-sm text-muted-foreground">
                Pick as many items across all 4 categories as you need.
              </p>
            </div>
            <Badge variant="info">{selectedIds.length} active</Badge>
          </div>

          <div className="grid gap-5 md:grid-cols-2">
            {RESTRICTION_SECTIONS.map((sec) => {
              const items = RESTRICTION_OPTIONS.filter((o) => o.group === sec.key);
              return (
                <div key={sec.key} className="rounded-2xl border bg-card p-5 shadow-card">
                  <h3 className="font-display text-lg font-bold">{sec.title}</h3>
                  <p className="mt-1 text-xs text-muted-foreground">{sec.subtitle}</p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {items.map((opt) => {
                      const active = selectedIds.includes(opt.id);
                      return (
                        <button
                          key={opt.id}
                          type="button"
                          aria-pressed={active}
                          onClick={() => toggleRestriction(opt.id)}
                          className={`rounded-full border px-3.5 py-1.5 text-xs font-semibold transition-all ${
                            active
                              ? "border-primary bg-primary text-primary-foreground shadow-sm"
                              : "bg-muted/40 text-foreground hover:bg-muted"
                          }`}
                        >
                          {active ? "✓ " : "+ "}
                          {opt.label}
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Step 2: Combined "What Can I Eat?" Output + Web Sources */}
        <section className="rounded-3xl border-2 border-primary/20 bg-card p-6 shadow-card sm:p-8">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b pb-4">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-primary">
                Personalized Guidance
              </p>
              <h2 className="mt-1 font-display text-2xl font-bold">
                What You Can Safely Eat Together
              </h2>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {guidance.activeLabels.length === 0 ? (
                <Badge variant="info">Showing general guidance</Badge>
              ) : (
                guidance.activeLabels.map((lbl) => (
                  <Badge key={lbl} variant="safe">
                    {lbl}
                  </Badge>
                ))
              )}
            </div>
          </div>

          <div className="mt-6 grid gap-6 lg:grid-cols-[1.3fr_1fr]">
            <div className="space-y-3">
              <h3 className="flex items-center gap-2 text-sm font-bold text-safe-foreground">
                <CheckCircle2 className="size-4 text-safe" aria-hidden /> Safe Meal &amp; Grocery
                Matches
              </h3>
              <div className="grid gap-3 sm:grid-cols-2">
                {guidance.safeMealIdeas.map((meal) => (
                  <div
                    key={meal.title}
                    className="rounded-2xl border border-safe/25 bg-safe-soft/40 p-4"
                  >
                    <p className="font-display font-bold text-foreground">{meal.title}</p>
                    <p className="mt-1 text-xs font-medium text-foreground/80">{meal.items}</p>
                    <p className="mt-2 text-xs text-muted-foreground">{meal.whySafe}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <div className="rounded-2xl border border-danger/25 bg-danger-soft/40 p-4">
                <h3 className="flex items-center gap-2 text-sm font-bold text-danger-foreground">
                  <AlertTriangle className="size-4 text-danger" aria-hidden /> Watch Out For &amp;
                  Avoid
                </h3>
                {guidance.strictAvoids.length === 0 ? (
                  <p className="mt-2 text-xs text-muted-foreground">
                    Select restrictions above to generate your combined avoidance list.
                  </p>
                ) : (
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {guidance.strictAvoids.slice(0, 14).map((item) => (
                      <Badge key={item} variant="danger" className="text-[11px]">
                        {item}
                      </Badge>
                    ))}
                  </div>
                )}
              </div>

              <div className="rounded-2xl border bg-muted/40 p-4">
                <h3 className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">
                  <BookOpen className="size-3.5 text-primary" aria-hidden /> Verified Reference
                  Sources
                </h3>
                <ul className="mt-2.5 space-y-2 text-xs">
                  {guidance.sources.map((src) => (
                    <li key={src.url}>
                      <a
                        href={src.url}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1 font-medium text-primary hover:underline"
                      >
                        {src.organization}: {src.title}
                        <ExternalLink className="size-3" aria-hidden />
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* Step 3: Paste Any Food Label to Catch Hidden Ingredients */}
        <section className="rounded-3xl border bg-card p-6 shadow-card sm:p-8">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className="font-display text-2xl font-bold">
                Step 2: Paste Any Ingredient Label
              </h2>
              <p className="text-sm text-muted-foreground">
                Instantly highlights allergens, vague binders, and hidden animal byproducts like{" "}
                <em>enzymes (animal rennet)</em> or <em>carmine</em>.
              </p>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {SAMPLE_SNACKS.map((s) => (
                <button
                  key={s.label}
                  type="button"
                  onClick={() => setLabelText(s.ingredients)}
                  className="rounded-full border bg-muted/50 px-3 py-1 text-xs font-semibold hover:border-primary"
                >
                  Try: {s.label}
                </button>
              ))}
            </div>
          </div>

          <textarea
            rows={3}
            value={labelText}
            onChange={(e) => setLabelText(e.target.value)}
            aria-label="Paste food ingredients"
            className="mt-4 w-full rounded-xl border border-input bg-background p-3.5 text-sm shadow-sm"
            placeholder="Paste the ingredients from the back of any package..."
          />

          <div className="mt-4 flex flex-wrap gap-1.5">
            {liveBadges.map((b, i) => (
              <span
                key={i}
                title={b.why}
                className={`rounded-lg border px-2.5 py-1 text-xs font-medium ${
                  b.tone === "secondary"
                    ? "border-caution/50 bg-caution-soft text-caution-foreground"
                    : b.tone === "top9"
                      ? "border-danger/30 bg-danger-soft text-danger-foreground"
                      : b.tone === "binder"
                        ? "border-info/30 bg-info-soft text-info-foreground"
                        : "border-safe/25 bg-safe-soft/50 text-safe-foreground"
                }`}
              >
                {b.text}
                {b.tone !== "safe" && <span className="ml-1 font-bold">({b.why})</span>}
              </span>
            ))}
          </div>

          {hiddenMatchesInLabel.length > 0 && (
            <div className="mt-5 space-y-2 rounded-2xl border-2 border-caution/50 bg-caution-soft/50 p-4">
              <p className="flex items-center gap-2 text-sm font-bold text-caution-foreground">
                <HelpCircle className="size-4" aria-hidden /> Hidden Ingredient Alert Detected in
                This Label
              </p>
              {hiddenMatchesInLabel.map((m) => (
                <div key={m.id} className="text-xs text-foreground/90">
                  <strong>{m.name}:</strong> {m.plainExplanation}{" "}
                  {m.sources[0] && (
                    <a
                      href={m.sources[0].url}
                      target="_blank"
                      rel="noreferrer"
                      className="font-semibold text-primary underline"
                    >
                      Source ({m.sources[0].organization})
                    </a>
                  )}
                </div>
              ))}
            </div>
          )}
        </section>

        {/* Step 4: Hidden Ingredients Encyclopedic Spotlight */}
        <section className="space-y-4">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <h2 className="font-display text-2xl font-bold">
                Hidden Ingredients Most People Don’t Know About
              </h2>
              <p className="text-sm text-muted-foreground">
                Why a bag of cheese chips, red yogurt, or gluten-free bread might not match your
                diet.
              </p>
            </div>
            <div className="relative">
              <Search
                className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
                aria-hidden
              />
              <input
                value={hiddenSearch}
                onChange={(e) => setHiddenSearch(e.target.value)}
                placeholder="Search rennet, chips, carmine..."
                aria-label="Search hidden ingredients"
                className="w-full rounded-xl border border-input bg-card py-2 pl-9 pr-3 text-sm sm:w-64"
              />
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredHiddenGuide.map((item) => (
              <article
                key={item.id}
                className="flex flex-col justify-between rounded-2xl border bg-card p-5 shadow-card"
              >
                <div>
                  <div className="flex items-center justify-between gap-2">
                    <Badge variant={item.severity === "high" ? "caution" : "info"}>
                      Affects: {item.affects.join(", ")}
                    </Badge>
                  </div>
                  <h3 className="mt-3 font-display text-lg font-bold leading-snug">{item.name}</h3>
                  <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
                    {item.plainExplanation}
                  </p>
                  <div className="mt-3 rounded-xl bg-muted/50 p-3 text-xs">
                    <p className="font-semibold text-foreground">Commonly found in:</p>
                    <ul className="mt-1 list-disc pl-4 text-muted-foreground">
                      {item.commonProducts.map((p) => (
                        <li key={p}>{p}</li>
                      ))}
                    </ul>
                  </div>
                  <p className="mt-3 text-xs font-medium text-safe-foreground">
                    <strong>Tip:</strong> {item.whatToLookFor}
                  </p>
                </div>

                <div className="mt-4 border-t pt-3 flex flex-wrap gap-3 text-[11px]">
                  {item.sources.map((s) => (
                    <a
                      key={s.url}
                      href={s.url}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1 font-semibold text-primary hover:underline"
                    >
                      {s.organization} <ExternalLink className="size-3" aria-hidden />
                    </a>
                  ))}
                </div>
              </article>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}
