import { createFileRoute } from "@tanstack/react-router";
import {
  Ban,
  CheckCircle2,
  ClipboardList,
  Minus,
  PackageCheck,
  PackagePlus,
  Printer,
  ShieldAlert,
  ShieldCheck,
  XCircle,
} from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";

import { PageHeader, Panel } from "@/components/equitable/AppShell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { BOX_TARGET } from "@/lib/equitable/data";
import { boxSafetyScore, evaluateItem, profileRestrictionLabels } from "@/lib/equitable/engine";
import { useEquiTable } from "@/lib/equitable/store";
import type { InventoryItem, PackingSlip } from "@/lib/equitable/types";

export const Route = createFileRoute("/packing")({
  head: () => ({
    meta: [
      { title: "Volunteer Box-Packing & Matching Station — EquiTable" },
      {
        name: "description",
        content:
          "Match pantry stock against a family's strict restrictions in real time and pack boxes that are 100% compliant.",
      },
      { property: "og:title", content: "EquiTable Box-Packing Station" },
      {
        property: "og:description",
        content: "Real-time matching engine and safe packing slips for volunteers.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PackingPage,
});

type Filter = "all" | "safe" | "rejected";

function PackingPage() {
  const { state, dispatch } = useEquiTable();
  const [filter, setFilter] = useState<Filter>("all");
  const [slip, setSlip] = useState<PackingSlip | null>(null);

  const profile = state.profiles.find((p) => p.id === state.selectedProfileId) ?? state.profiles[0];
  const lines = profile ? (state.boxes[profile.id] ?? []) : [];
  const packedCount = lines.reduce((n, l) => n + l.count, 0);

  const verdicts = useMemo(
    () =>
      profile
        ? state.inventory.map((item) => ({ item, verdict: evaluateItem(profile, item) }))
        : [],
    [state.inventory, profile],
  );
  const safe = verdicts.filter((v) => v.verdict.safe);
  const rejected = verdicts.filter((v) => !v.verdict.safe);
  const recommended = safe.filter((v) => v.item.quantity > 0).sort((a, b) => b.item.quantity - a.item.quantity).slice(0, 6);

  const packedFacts = lines.flatMap((l) => {
    const i = state.inventory.find((x) => x.id === l.itemId);
    return i ? Array<InventoryItem>(l.count).fill(i) : [];
  });
  const score = profile ? boxSafetyScore(profile, packedFacts) : 100;
  const fill = Math.min(100, Math.round((packedCount / BOX_TARGET) * 100));

  if (!profile) {
    return (
      <div>
        <PageHeader eyebrow="Step 2 · Packing" title="Box-Packing Station" />
        <Panel>
          <p className="text-muted-foreground">Add a family profile first to start packing.</p>
        </Panel>
      </div>
    );
  }

  const r = profileRestrictionLabels(profile);
  const pack = (item: InventoryItem) => {
    dispatch({ type: "pack", profileId: profile.id, itemId: item.id });
    toast.success(`Packed ${item.name}`, { description: `Verified safe for Family #${profile.code}` });
  };

  const complete = () => {
    const id = `slip-${Date.now()}`;
    const preview: PackingSlip = {
      id,
      profileId: profile.id,
      profileCode: profile.code,
      profileSummary: profile.summary,
      lines,
      safetyScore: score,
      packedAt: new Date().toLocaleString(),
    };
    dispatch({ type: "complete", profileId: profile.id, slipId: id });
    setSlip(preview);
    toast.success(`Box sealed for Family #${profile.code}`);
  };

  const rows = filter === "safe" ? safe : filter === "rejected" ? rejected : verdicts;

  return (
    <div>
      <PageHeader
        eyebrow="Step 2 · Packing"
        title="Box-Packing & Matching Station"
        description="Choose a family. The matching engine checks every item in stock against their restrictions — only verified-safe items can go in the box."
      />

      <div className="mb-6 flex flex-col gap-3 rounded-2xl border bg-card p-4 shadow-card sm:flex-row sm:items-center">
        <label htmlFor="family" className="text-sm font-semibold sm:w-32">
          Client profile
        </label>
        <select
          id="family"
          value={profile.id}
          onChange={(e) => dispatch({ type: "selectProfile", id: e.target.value })}
          className="flex-1 rounded-lg border border-input bg-card px-3 py-2.5 text-sm font-medium shadow-sm"
        >
          {state.profiles.map((p) => (
            <option key={p.id} value={p.id}>
              Family #{p.code} - {p.summary}
              {p.status !== "pending" ? ` (${p.status === "packed" ? "box packed" : "picked up"})` : ""}
            </option>
          ))}
        </select>
        <Badge variant={profile.status === "pending" ? "caution" : "safe"} className="self-start sm:self-auto">
          {profile.status === "pending" ? "Pending pickup" : profile.status === "packed" ? "Box packed" : "Picked up"}
        </Badge>
      </div>

      <div className="grid gap-6 lg:grid-cols-[minmax(300px,380px)_1fr]">
        {/* LEFT: restrictions + box */}
        <div className="space-y-6">
          <Panel
            title={`Family #${profile.code} restrictions`}
            icon={<ShieldAlert className="size-4 text-danger" aria-hidden />}
          >
            <div className="space-y-4 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Household size</span>
                <span className="font-semibold">{profile.householdSize}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Severity</span>
                <Badge variant={profile.severity === "severe" ? "solidDanger" : profile.severity === "moderate" ? "caution" : "info"} className="uppercase">
                  {profile.severity}
                </Badge>
              </div>
              <RestrictionGroup label="Top 9 allergens" items={r.top9} tone="danger" />
              <RestrictionGroup label="Secondary allergens" items={r.secondary} tone="caution" />
              <RestrictionGroup label="Medical" items={r.conditions} tone="info" />
              <RestrictionGroup label="Religious / cultural" items={r.religious} tone="safe" />
              {profile.notes && (
                <p className="rounded-lg bg-muted p-3 text-xs text-muted-foreground">{profile.notes}</p>
              )}
            </div>
          </Panel>

          <Panel title="Current box" icon={<PackageCheck className="size-4 text-primary" aria-hidden />}>
            <div className="space-y-4">
              <div>
                <div className="mb-1.5 flex justify-between text-xs font-semibold">
                  <span>Box fill</span>
                  <span className="tabular-nums">
                    {packedCount} / {BOX_TARGET} items
                  </span>
                </div>
                <div
                  className="h-2.5 overflow-hidden rounded-full bg-muted"
                  role="progressbar"
                  aria-label="Box fill"
                  aria-valuenow={fill}
                  aria-valuemin={0}
                  aria-valuemax={100}
                >
                  <div className="h-full bg-brand-gradient transition-all duration-500" style={{ width: `${fill}%` }} />
                </div>
              </div>
              <div
                className={`flex items-center gap-3 rounded-xl border-2 p-3 ${
                  score === 100 ? "border-safe/40 bg-safe-soft text-safe-foreground" : "border-danger/40 bg-danger-soft text-danger-foreground"
                }`}
              >
                <ShieldCheck className="size-6 shrink-0" aria-hidden />
                <div>
                  <p className="font-display font-bold">Box Safety Score: {score}% Compliant</p>
                  <div className="mt-1 h-1.5 w-40 overflow-hidden rounded-full bg-card">
                    <div className={`h-full ${score === 100 ? "bg-safe" : "bg-danger"}`} style={{ width: `${score}%` }} />
                  </div>
                </div>
              </div>

              {lines.length === 0 ? (
                <p className="py-4 text-center text-sm text-muted-foreground">Box is empty — pack a verified item.</p>
              ) : (
                <ul className="divide-y rounded-lg border">
                  {lines.map((l) => (
                    <li key={l.itemId} className="flex items-center gap-2 px-3 py-2 text-sm">
                      <CheckCircle2 className="size-4 shrink-0 text-safe" aria-hidden />
                      <span className="flex-1">{l.name}</span>
                      <span className="font-mono text-xs tabular-nums">×{l.count}</span>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="size-7"
                        aria-label={`Remove one ${l.name}`}
                        onClick={() => dispatch({ type: "unpack", profileId: profile.id, itemId: l.itemId })}
                      >
                        <Minus />
                      </Button>
                    </li>
                  ))}
                </ul>
              )}
              <Button className="w-full" size="lg" disabled={lines.length === 0} onClick={complete}>
                <ClipboardList /> Seal Box & View Packing Slip
              </Button>
              {state.slips[0] && (
                <Button variant="outline" className="w-full" onClick={() => setSlip(state.slips[0] ?? null)}>
                  View last packing slip (#{state.slips[0].profileCode})
                </Button>
              )}
            </div>
          </Panel>
        </div>

        {/* RIGHT: recommendations + verification table */}
        <div className="space-y-6">
          <Panel
            title="Recommended from pantry stock"
            icon={<PackagePlus className="size-4 text-primary" aria-hidden />}
            action={<Badge variant="safe">{safe.length} safe matches</Badge>}
          >
            {recommended.length === 0 ? (
              <p className="text-sm text-muted-foreground">No safe items in stock for this family right now.</p>
            ) : (
              <ul className="grid gap-3 sm:grid-cols-2">
                {recommended.map(({ item }) => (
                  <li key={item.id} className="flex items-center gap-3 rounded-xl border border-safe/25 bg-safe-soft/50 p-3">
                    <CheckCircle2 className="size-5 shrink-0 text-safe" aria-hidden />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold">{item.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {item.category} · {item.quantity} left
                      </p>
                    </div>
                    <Button size="sm" onClick={() => pack(item)} aria-label={`Pack ${item.name} into box`}>
                      Pack
                    </Button>
                  </li>
                ))}
              </ul>
            )}
          </Panel>

          <Panel
            title="Instant Verification Table"
            action={
              <div role="tablist" aria-label="Filter items" className="flex rounded-lg bg-muted p-1 text-xs font-semibold">
                {(
                  [
                    ["all", `All ${verdicts.length}`],
                    ["safe", `Safe ${safe.length}`],
                    ["rejected", `Rejected ${rejected.length}`],
                  ] as const
                ).map(([k, label]) => (
                  <button
                    key={k}
                    role="tab"
                    aria-selected={filter === k}
                    onClick={() => setFilter(k)}
                    className={`rounded-md px-2.5 py-1 transition-colors ${filter === k ? "bg-card shadow-sm" : "text-muted-foreground"}`}
                  >
                    {label}
                  </button>
                ))}
              </div>
            }
          >
            <div className="-mx-5 -my-5 overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 text-left text-xs uppercase tracking-wider text-muted-foreground">
                  <tr>
                    <th scope="col" className="px-5 py-3">Status</th>
                    <th scope="col" className="px-5 py-3">Item</th>
                    <th scope="col" className="px-5 py-3">Verification</th>
                    <th scope="col" className="px-5 py-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {rows.map(({ item, verdict }) => (
                    <tr key={item.id} className={verdict.safe ? "" : "bg-danger-soft/40"}>
                      <td className="px-5 py-3">
                        {verdict.safe ? (
                          <span className="inline-flex items-center gap-1.5 font-semibold text-safe-foreground">
                            <CheckCircle2 className="size-5 text-safe" aria-hidden /> Verified Safe
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 font-semibold text-danger-foreground">
                            <XCircle className="size-5 text-danger" aria-hidden /> Rejected
                          </span>
                        )}
                      </td>
                      <td className="px-5 py-3">
                        <p className="font-medium">{item.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {item.brand} · {item.quantity} in stock
                        </p>
                      </td>
                      <td className="px-5 py-3">
                        {verdict.safe ? (
                          <span className="text-xs text-muted-foreground">Passes all {profile.allergens.length + profile.conditions.length + profile.religious.length} rules</span>
                        ) : (
                          <div className="flex flex-wrap gap-1">
                            {verdict.reasons.map((reason) => (
                              <Badge key={reason} variant="danger" className="text-[11px]">
                                {reason}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </td>
                      <td className="px-5 py-3 text-right">
                        {verdict.safe ? (
                          <Button size="sm" variant="outline" disabled={item.quantity === 0} onClick={() => pack(item)}>
                            <PackagePlus /> Pack Item into Box
                          </Button>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-xs font-semibold text-danger-foreground">
                            <Ban className="size-3.5" aria-hidden /> Blocked
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Panel>
        </div>
      </div>

      <Dialog open={!!slip} onOpenChange={(o) => !o && setSlip(null)}>
        <DialogContent className="print-area max-w-lg">
          {slip && (
            <>
              <DialogHeader>
                <DialogTitle className="font-display text-2xl">Safe Packing Slip</DialogTitle>
                <DialogDescription>
                  Family #{slip.profileCode} · {slip.profileSummary}
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 text-sm">
                <div className="flex items-center gap-2 rounded-lg border-2 border-safe/40 bg-safe-soft p-3 font-semibold text-safe-foreground">
                  <ShieldCheck className="size-5" aria-hidden /> Box Safety Score: {slip.safetyScore}% Compliant
                </div>
                <table className="w-full">
                  <thead className="text-left text-xs uppercase text-muted-foreground">
                    <tr>
                      <th className="py-1">Item</th>
                      <th className="py-1">Brand</th>
                      <th className="py-1 text-right">Qty</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y border-y">
                    {slip.lines.map((l) => (
                      <tr key={l.itemId}>
                        <td className="py-2 font-medium">
                          <CheckCircle2 className="mr-1.5 inline size-4 text-safe" aria-hidden />
                          {l.name}
                        </td>
                        <td className="py-2 text-muted-foreground">{l.brand}</td>
                        <td className="py-2 text-right font-mono">{l.count}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                <p className="text-xs text-muted-foreground">
                  Packed {slip.packedAt} · Verified by EquiTable deterministic rule engine · No personal
                  information stored.
                </p>
              </div>
              <div className="no-print flex justify-end gap-2">
                <Button variant="outline" onClick={() => setSlip(null)}>
                  Close
                </Button>
                <Button onClick={() => window.print()}>
                  <Printer /> Print slip
                </Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function RestrictionGroup({
  label,
  items,
  tone,
}: {
  label: string;
  items: string[];
  tone: "danger" | "caution" | "info" | "safe";
}) {
  return (
    <div>
      <p className="mb-1.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</p>
      {items.length === 0 ? (
        <p className="text-xs text-muted-foreground">None</p>
      ) : (
        <div className="flex flex-wrap gap-1.5">
          {items.map((i) => (
            <Badge key={i} variant={tone}>
              {i}
            </Badge>
          ))}
        </div>
      )}
    </div>
  );
}
