/* eslint-disable */

// @ts-nocheck

// noinspection JSUnusedGlobalSymbols

import { Route as rootRouteImport } from './routes/__root'
import { Route as IndexRouteImport } from './routes/index'
import { Route as RightbiteRouteImport } from './routes/rightbite'
import { Route as EquitableRouteImport } from './routes/equitable'
import { Route as IntakeRouteImport } from './routes/intake'
import { Route as PackingRouteImport } from './routes/packing'
import { Route as ProfilesRouteImport } from './routes/profiles'

const IndexRoute = IndexRouteImport.update({
  id: '/',
  path: '/',
  getParentRoute: () => rootRouteImport,
} as any)
const RightbiteRoute = RightbiteRouteImport.update({
  id: '/rightbite',
  path: '/rightbite',
  getParentRoute: () => rootRouteImport,
} as any)
const EquitableRoute = EquitableRouteImport.update({
  id: '/equitable',
  path: '/equitable',
  getParentRoute: () => rootRouteImport,
} as any)
const IntakeRoute = IntakeRouteImport.update({
  id: '/intake',
  path: '/intake',
  getParentRoute: () => rootRouteImport,
} as any)
const PackingRoute = PackingRouteImport.update({
  id: '/packing',
  path: '/packing',
  getParentRoute: () => rootRouteImport,
} as any)
const ProfilesRoute = ProfilesRouteImport.update({
  id: '/profiles',
  path: '/profiles',
  getParentRoute: () => rootRouteImport,
} as any)

export interface FileRoutesByFullPath {
  '/': typeof IndexRoute
  '/rightbite': typeof RightbiteRoute
  '/equitable': typeof EquitableRoute
  '/intake': typeof IntakeRoute
  '/packing': typeof PackingRoute
  '/profiles': typeof ProfilesRoute
}
export interface FileRoutesByTo {
  '/': typeof IndexRoute
  '/rightbite': typeof RightbiteRoute
  '/equitable': typeof EquitableRoute
  '/intake': typeof IntakeRoute
  '/packing': typeof PackingRoute
  '/profiles': typeof ProfilesRoute
}
export interface FileRoutesById {
  __root__: typeof rootRouteImport
  '/': typeof IndexRoute
  '/rightbite': typeof RightbiteRoute
  '/equitable': typeof EquitableRoute
  '/intake': typeof IntakeRoute
  '/packing': typeof PackingRoute
  '/profiles': typeof ProfilesRoute
}
export interface FileRouteTypes {
  fileRoutesByFullPath: FileRoutesByFullPath
  fullPaths: '/' | '/rightbite' | '/equitable' | '/intake' | '/packing' | '/profiles'
  fileRoutesByTo: FileRoutesByTo
  to: '/' | '/rightbite' | '/equitable' | '/intake' | '/packing' | '/profiles'
  id: '__root__' | '/' | '/rightbite' | '/equitable' | '/intake' | '/packing' | '/profiles'
  fileRoutesById: FileRoutesById
}
export interface RootRouteChildren {
  IndexRoute: typeof IndexRoute
  RightbiteRoute: typeof RightbiteRoute
  EquitableRoute: typeof EquitableRoute
  IntakeRoute: typeof IntakeRoute
  PackingRoute: typeof PackingRoute
  ProfilesRoute: typeof ProfilesRoute
}

declare module '@tanstack/react-router' {
  interface FileRoutesByPath {
    '/': {
      id: '/'
      path: '/'
      fullPath: '/'
      preLoaderRoute: typeof IndexRouteImport
      parentRoute: typeof rootRouteImport
    }
    '/rightbite': {
      id: '/rightbite'
      path: '/rightbite'
      fullPath: '/rightbite'
      preLoaderRoute: typeof RightbiteRouteImport
      parentRoute: typeof rootRouteImport
    }
    '/equitable': {
      id: '/equitable'
      path: '/equitable'
      fullPath: '/equitable'
      preLoaderRoute: typeof EquitableRouteImport
      parentRoute: typeof rootRouteImport
    }
    '/intake': {
      id: '/intake'
      path: '/intake'
      fullPath: '/intake'
      preLoaderRoute: typeof IntakeRouteImport
      parentRoute: typeof rootRouteImport
    }
    '/packing': {
      id: '/packing'
      path: '/packing'
      fullPath: '/packing'
      preLoaderRoute: typeof PackingRouteImport
      parentRoute: typeof rootRouteImport
    }
    '/profiles': {
      id: '/profiles'
      path: '/profiles'
      fullPath: '/profiles'
      preLoaderRoute: typeof ProfilesRouteImport
      parentRoute: typeof rootRouteImport
    }
  }
}

const rootRouteChildren: RootRouteChildren = {
  IndexRoute: IndexRoute,
  RightbiteRoute: RightbiteRoute,
  EquitableRoute: EquitableRoute,
  IntakeRoute: IntakeRoute,
  PackingRoute: PackingRoute,
  ProfilesRoute: ProfilesRoute,
}
export const routeTree = rootRouteImport
  ._addFileChildren(rootRouteChildren)
  ._addFileTypes<FileRouteTypes>()

import type { getRouter } from './router.tsx'
import type { startInstance } from './start.ts'
declare module '@tanstack/react-start' {
  interface Register {
    ssr: true
    router: Awaited<ReturnType<typeof getRouter>>
    config: Awaited<ReturnType<typeof startInstance.getOptions>>
  }
}
