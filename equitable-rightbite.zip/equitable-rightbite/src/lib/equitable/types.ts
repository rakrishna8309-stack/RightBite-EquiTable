export type Allergen =
  | "peanut"
  | "treenut"
  | "milk"
  | "egg"
  | "fish"
  | "shellfish"
  | "soy"
  | "wheat"
  | "sesame"
  | "lupin"
  | "mustard"
  | "sulfites"
  | "seeds";

export type Condition = "celiac" | "diabetes";
export type Religious = "halal" | "kosher" | "vegetarian";
export type Severity = "severe" | "moderate" | "mild";
export type PickupStatus = "pending" | "packed" | "picked-up";

export const TOP9: Allergen[] = [
  "peanut",
  "treenut",
  "milk",
  "egg",
  "fish",
  "shellfish",
  "soy",
  "wheat",
  "sesame",
];
export const SECONDARY: Allergen[] = ["lupin", "mustard", "sulfites", "seeds"];
export const CONDITIONS: Condition[] = ["celiac", "diabetes"];
export const RELIGIOUS: Religious[] = ["halal", "kosher", "vegetarian"];

export const ALLERGEN_LABEL: Record<Allergen, string> = {
  peanut: "Peanut",
  treenut: "Tree Nut",
  milk: "Milk",
  egg: "Egg",
  fish: "Fish",
  shellfish: "Shellfish",
  soy: "Soy",
  wheat: "Wheat",
  sesame: "Sesame",
  lupin: "Lupin",
  mustard: "Mustard",
  sulfites: "Sulfites",
  seeds: "Seeds",
};

export const CONDITION_LABEL: Record<Condition, string> = {
  celiac: "Celiac Disease",
  diabetes: "Diabetes / Low Sugar",
};

export const RELIGIOUS_LABEL: Record<Religious, string> = {
  halal: "Halal",
  kosher: "Kosher",
  vegetarian: "Vegetarian",
};

/** Facts about a food item that the rule engine evaluates. */
export interface FoodFacts {
  allergens: Allergen[];
  mayContain: Allergen[];
  gluten: boolean;
  gelatin: boolean;
  meat: boolean;
  pork: boolean;
  sugarG: number;
  halalCertified: boolean;
  kosherCertified: boolean;
}

export interface InventoryItem extends FoodFacts {
  id: string;
  name: string;
  brand: string;
  category: string;
  quantity: number;
  ingredients: string;
}

export interface FamilyProfile {
  id: string;
  code: string;
  summary: string;
  householdSize: number;
  severity: Severity;
  allergens: Allergen[];
  conditions: Condition[];
  religious: Religious[];
  notes: string;
  status: PickupStatus;
}

export type Tone = "safe" | "caution" | "danger" | "info";

export interface Activity {
  id: string;
  text: string;
  tone: Tone;
  createdAt: string;
}

export interface PackedLine {
  itemId: string;
  name: string;
  brand: string;
  count: number;
}

export interface PackingSlip {
  id: string;
  profileId: string;
  profileCode: string;
  profileSummary: string;
  lines: PackedLine[];
  safetyScore: number;
  exclusions: string[];
  /** ISO timestamp */
  packedAt: string;
}

export interface PantryMetrics {
  scanned: number;
  matched: number;
  intercepted: number;
  boxes: number;
}

export interface PantrySnapshot {
  inventory: InventoryItem[];
  profiles: FamilyProfile[];
  boxes: Record<string, PackedLine[]>;
  slips: PackingSlip[];
  activity: Activity[];
  metrics: PantryMetrics;
}
