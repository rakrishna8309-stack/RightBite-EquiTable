import type { Activity, Allergen, FamilyProfile, InventoryItem } from "./types";

const base = {
  mayContain: [] as Allergen[],
  gluten: false,
  gelatin: false,
  meat: false,
  pork: false,
  halalCertified: false,
  kosherCertified: false,
};

export interface SampleScan {
  id: string;
  label: string;
  name: string;
  brand: string;
  category: string;
  ingredients: string;
  sugarG: number;
  halalCertified: boolean;
  kosherCertified: boolean;
  confidence: number;
}

export const SAMPLE_SCANS: SampleScan[] = [
  {
    id: "A",
    label: "Item A — Protein Bar",
    name: "Peak Protein Bar",
    brand: "TrailFuel",
    category: "Snacks",
    ingredients:
      "Ingredients: Protein blend (whey concentrate, brown rice protein), brown rice syrup, lupin flour, cocoa butter, natural flavors, sea salt, rosemary extract",
    sugarG: 14,
    halalCertified: false,
    kosherCertified: false,
    confidence: 97.8,
  },
  {
    id: "B",
    label: "Item B — Organic Vegetable Soup",
    name: "Organic Vegetable Soup",
    brand: "Greenfield Kitchen",
    category: "Canned Goods",
    ingredients:
      "Ingredients: Water, carrots, celery, potatoes, tomato paste, onions, mustard seed, sea salt, sodium phosphate, potassium metabisulfite (sulfites), garlic, black pepper",
    sugarG: 4,
    halalCertified: false,
    kosherCertified: false,
    confidence: 98.6,
  },
  {
    id: "C",
    label: "Item C — Rice & Beans Pack",
    name: "Rice & Beans Pack",
    brand: "Harvest Table",
    category: "Grains",
    ingredients:
      "Ingredients: Long-grain white rice, black beans, dehydrated onion, garlic, cumin, olive oil, sea salt",
    sugarG: 1,
    halalCertified: true,
    kosherCertified: false,
    confidence: 99.2,
  },
];

export const INITIAL_INVENTORY: InventoryItem[] = [
  { ...base, id: "inv-01", name: "Rice & Beans Pack", brand: "Harvest Table", category: "Grains", quantity: 24, allergens: [], sugarG: 1, halalCertified: true, ingredients: "White rice, black beans, onion, garlic, cumin, olive oil, sea salt" },
  { ...base, id: "inv-02", name: "Certified GF Rolled Oats", brand: "Prairie Mill", category: "Breakfast", quantity: 18, allergens: [], sugarG: 1, kosherCertified: true, ingredients: "Gluten-free whole grain oats" },
  { ...base, id: "inv-03", name: "Creamy Peanut Butter", brand: "Sunny Acres", category: "Spreads", quantity: 15, allergens: ["peanut"], sugarG: 3, kosherCertified: true, ingredients: "Roasted peanuts, salt" },
  { ...base, id: "inv-04", name: "Whole Wheat Penne", brand: "Nonna's", category: "Pasta", quantity: 30, allergens: ["wheat"], gluten: true, sugarG: 2, halalCertified: true, kosherCertified: true, ingredients: "Whole durum wheat semolina" },
  { ...base, id: "inv-05", name: "Fruit Gummy Snacks", brand: "Jolly Bites", category: "Snacks", quantity: 40, allergens: [], gelatin: true, sugarG: 18, ingredients: "Corn syrup, sugar, gelatin, fruit juice concentrate, citric acid" },
  { ...base, id: "inv-06", name: "Canned Chickpeas", brand: "Greenfield Kitchen", category: "Canned Goods", quantity: 36, allergens: [], sugarG: 0, halalCertified: true, kosherCertified: true, ingredients: "Chickpeas, water, salt" },
  { ...base, id: "inv-07", name: "Chunk Light Tuna", brand: "Blue Harbor", category: "Protein", quantity: 22, allergens: ["fish"], sugarG: 0, kosherCertified: true, ingredients: "Light tuna, water, salt" },
  { ...base, id: "inv-08", name: "Unsweetened Almond Milk", brand: "Orchard Pure", category: "Dairy Alternatives", quantity: 12, allergens: ["treenut"], sugarG: 0, halalCertified: true, kosherCertified: true, ingredients: "Almond milk (water, almonds), calcium carbonate, sea salt" },
  { ...base, id: "inv-09", name: "Sesame Rice Crackers", brand: "Lotus Road", category: "Snacks", quantity: 16, allergens: ["sesame", "soy"], sugarG: 2, ingredients: "Rice flour, sesame seeds, soy sauce (soybeans, salt)" },
  { ...base, id: "inv-10", name: "Halal Chicken Breast (Canned)", brand: "Crescent Farms", category: "Protein", quantity: 14, allergens: [], meat: true, sugarG: 0, halalCertified: true, ingredients: "Chicken breast, water, salt" },
  { ...base, id: "inv-11", name: "Red Lentils", brand: "Prairie Mill", category: "Grains", quantity: 28, allergens: [], sugarG: 1, halalCertified: true, kosherCertified: true, ingredients: "Red lentils" },
  { ...base, id: "inv-12", name: "Unsweetened Applesauce", brand: "Orchard Pure", category: "Fruit", quantity: 26, allergens: [], sugarG: 9, halalCertified: true, kosherCertified: true, ingredients: "Apples, water, ascorbic acid" },
  { ...base, id: "inv-13", name: "Marshmallow Crisp Cereal", brand: "Morning Star", category: "Breakfast", quantity: 10, allergens: ["wheat"], gluten: true, gelatin: true, sugarG: 16, ingredients: "Wheat flour, sugar, marshmallows (sugar, corn syrup, gelatin)" },
  { ...base, id: "inv-14", name: "Granola Clusters", brand: "TrailFuel", category: "Breakfast", quantity: 11, allergens: ["treenut"], mayContain: ["peanut", "lupin"], gluten: true, sugarG: 12, ingredients: "Oats, honey, almonds, barley malt. May contain peanut, lupin" },
  { ...base, id: "inv-15", name: "Brown Basmati Rice", brand: "Harvest Table", category: "Grains", quantity: 20, allergens: [], sugarG: 0, halalCertified: true, kosherCertified: true, ingredients: "Brown basmati rice" },
  { ...base, id: "inv-16", name: "Low-Sodium Black Beans", brand: "Greenfield Kitchen", category: "Canned Goods", quantity: 32, allergens: [], sugarG: 0, halalCertified: true, kosherCertified: true, ingredients: "Black beans, water, sea salt" },
  { ...base, id: "inv-17", name: "Dijon Vinaigrette", brand: "Maison Claire", category: "Condiments", quantity: 8, allergens: ["mustard", "sulfites"], sugarG: 3, ingredients: "Water, vinegar, mustard seed, white wine (sulfites), oil" },
  { ...base, id: "inv-18", name: "Shelf-Stable Whole Milk", brand: "Valley Dairy", category: "Dairy", quantity: 9, allergens: ["milk"], sugarG: 12, halalCertified: true, kosherCertified: true, ingredients: "Whole milk, vitamin D3" },
];

export const INITIAL_PROFILES: FamilyProfile[] = [
  { id: "fam-1042", code: "1042", summary: "Severe Peanut Anaphylaxis & Celiac", householdSize: 4, severity: "severe", allergens: ["peanut"], conditions: ["celiac"], religious: [], notes: "Child carries epinephrine. Strict no cross-contact.", status: "pending" },
  { id: "fam-2089", code: "2089", summary: "Halal & Dairy Sensitivity", householdSize: 6, severity: "moderate", allergens: ["milk"], conditions: [], religious: ["halal"], notes: "Prefers rice and legumes.", status: "pending" },
  { id: "fam-3317", code: "3317", summary: "Severe Celiac & Lupin Allergy", householdSize: 3, severity: "severe", allergens: ["lupin"], conditions: ["celiac"], religious: [], notes: "Lupin reaction confirmed by allergist.", status: "pending" },
  { id: "fam-4120", code: "4120", summary: "Kosher & Shellfish Allergy", householdSize: 5, severity: "moderate", allergens: ["shellfish"], conditions: [], religious: ["kosher"], notes: "", status: "packed" },
  { id: "fam-5204", code: "5204", summary: "Diabetes & Vegetarian", householdSize: 2, severity: "mild", allergens: [], conditions: ["diabetes"], religious: ["vegetarian"], notes: "Senior household, low sugar items preferred.", status: "pending" },
  { id: "fam-6011", code: "6011", summary: "Severe Celiac, Lupin & Mustard", householdSize: 4, severity: "severe", allergens: ["lupin", "mustard"], conditions: ["celiac"], religious: [], notes: "", status: "pending" },
  { id: "fam-7356", code: "7356", summary: "Tree Nut, Sesame & Halal", householdSize: 7, severity: "moderate", allergens: ["treenut", "sesame"], conditions: [], religious: ["halal"], notes: "", status: "picked-up" },
];

export const INITIAL_ACTIVITY: Activity[] = [
  { id: "act-1", text: "Intercepted Granola Clusters — may contain Lupin", tone: "caution", time: "2:41 PM" },
  { id: "act-2", text: "Box packed for Family #4120 — 100% compliant", tone: "safe", time: "2:18 PM" },
  { id: "act-3", text: "Rejected Fruit Gummy Snacks for Halal family — hidden gelatin", tone: "danger", time: "1:57 PM" },
  { id: "act-4", text: "24 × Rice & Beans Pack scanned and tagged Halal", tone: "safe", time: "1:30 PM" },
  { id: "act-5", text: "New profile added: Family #6011", tone: "info", time: "12:52 PM" },
];

export const INITIAL_METRICS = {
  scanned: 47,
  matched: 18,
  intercepted: 31,
  boxes: 22,
};

export const BOX_TARGET = 8;
