import {
  ALLERGEN_LABEL,
  CONDITION_LABEL,
  RELIGIOUS_LABEL,
  SECONDARY,
  TOP9,
  type Allergen,
  type FamilyProfile,
  type FoodFacts,
  type Tone,
} from "./types";

/** Sugar above this many grams per serving is rejected for diabetes / low-sugar profiles. */
export const LOW_SUGAR_LIMIT_G = 10;

export interface Verdict {
  safe: boolean;
  reasons: string[];
}

/**
 * Deterministic matching: every rejection traces back to an explicit rule,
 * so the same item + profile always gives the same answer.
 */
export function evaluateItem(profile: FamilyProfile, item: FoodFacts): Verdict {
  const reasons: string[] = [];

  for (const a of profile.allergens) {
    if (item.allergens.includes(a)) reasons.push(`Contains ${ALLERGEN_LABEL[a]}`);
    else if (item.mayContain.includes(a))
      reasons.push(`May contain ${ALLERGEN_LABEL[a]} (cross-contact)`);
  }

  if (profile.conditions.includes("celiac") && (item.gluten || item.allergens.includes("wheat"))) {
    reasons.push("Contains gluten (Celiac)");
  }
  if (profile.conditions.includes("diabetes") && item.sugarG > LOW_SUGAR_LIMIT_G) {
    reasons.push(`High sugar (${item.sugarG}g / serving)`);
  }

  if (profile.religious.includes("halal")) {
    if (item.pork) reasons.push("Contains pork (not Halal)");
    else if (item.gelatin && !item.halalCertified) reasons.push("Contains Hidden Gelatin");
    else if (item.meat && !item.halalCertified) reasons.push("Meat not Halal certified");
  }
  if (profile.religious.includes("kosher")) {
    if (item.pork) reasons.push("Contains pork (not Kosher)");
    else if (item.allergens.includes("shellfish")) reasons.push("Shellfish (not Kosher)");
    else if (item.gelatin && !item.kosherCertified) reasons.push("Contains Hidden Gelatin");
    else if (item.meat && !item.kosherCertified) reasons.push("Meat not Kosher certified");
  }
  if (profile.religious.includes("vegetarian")) {
    if (item.gelatin) reasons.push("Contains Hidden Gelatin (animal)");
    else if (
      item.meat ||
      item.pork ||
      item.allergens.includes("fish") ||
      item.allergens.includes("shellfish")
    )
      reasons.push("Contains meat or seafood");
  }

  return { safe: reasons.length === 0, reasons: Array.from(new Set(reasons)) };
}

/** Percent of packed items that still pass every rule for this profile. */
export function boxSafetyScore(profile: FamilyProfile, items: FoodFacts[]): number {
  if (items.length === 0) return 100;
  const safe = items.filter((i) => evaluateItem(profile, i).safe).length;
  return Math.round((safe / items.length) * 100);
}

export function restrictionCount(p: FamilyProfile): number {
  return p.allergens.length + p.conditions.length + p.religious.length;
}

export function describeProfile(p: Pick<FamilyProfile, "allergens" | "conditions" | "religious" | "severity">): string {
  const parts: string[] = [];
  const sev = p.severity === "severe" ? "Severe " : "";
  if (p.allergens.length) {
    parts.push(
      `${sev}${p.allergens
        .slice(0, 2)
        .map((a) => ALLERGEN_LABEL[a])
        .join(" & ")}${p.allergens.length > 2 ? " +" + (p.allergens.length - 2) : ""} allergy`,
    );
  }
  parts.push(...p.conditions.map((c) => (c === "celiac" ? "Celiac" : "Low Sugar")));
  parts.push(...p.religious.map((r) => RELIGIOUS_LABEL[r]));
  return parts.length ? parts.join(" & ") : "No restrictions";
}

/* ---------------------------- Label parsing ---------------------------- */

type FlagKind = "top9" | "secondary" | "dietary" | "info";

export interface IngredientToken {
  text: string;
  kind: FlagKind | "clean";
  flags: string[];
}

export interface ParsedLabel extends Omit<FoodFacts, "sugarG" | "halalCertified" | "kosherCertified"> {
  tokens: IngredientToken[];
  addedSugar: boolean;
  sodium: boolean;
}

const ALLERGEN_PATTERNS: Record<Allergen, RegExp> = {
  peanut: /peanut|groundnut|arachis/i,
  treenut: /almond|cashew|walnut|pecan|hazelnut|pistachio|macadamia|brazil nut/i,
  milk: /\bwhey|casein|lactose|cheese|ghee|\bcream\b|(?<!(almond|oat|soy|coconut|rice) )\bmilk|(?<!(cocoa|shea|peanut|almond|nut|seed) )\bbutter\b/i,
  egg: /\beggs?\b|albumin|albumen/i,
  fish: /\bfish|anchov|tuna|salmon|\bcod\b|tilapia|sardine/i,
  shellfish: /shrimp|crab|lobster|prawn|shellfish|\bclam|oyster|mussel/i,
  soy: /\bsoy|soya|edamame|tofu/i,
  wheat: /(?<!buck)wheat|semolina|spelt|durum|farina|couscous/i,
  sesame: /sesame|tahini/i,
  lupin: /lupin/i,
  mustard: /mustard/i,
  sulfites: /sulfit|sulphit|sulfur dioxide|sulphur dioxide/i,
  seeds: /sunflower|poppy|flax|chia|pumpkin seed|hemp seed/i,
};

const GLUTEN = /(?<!buck)wheat|barley|\brye\b|\bmalt|semolina|spelt|durum|farina|couscous|gluten(?![- ]free)/i;
const GELATIN = /gelatin/i;
const PORK = /pork|\blard\b|bacon|\bham\b/i;
const MEAT = /chicken|beef|\blamb\b|turkey|\bmeat\b|pork|\blard\b|bacon|\bham\b/i;
const SUGAR = /sugar|syrup|dextrose|fructose|honey/i;
const SODIUM = /sodium|\bsalt\b/i;

export function tokenizeIngredients(text: string): string[] {
  return text
    .replace(/^\s*ingredients\s*:/i, "")
    .split(/[,;()\[\]\n]|\.\s/)
    .map((t) => t.trim().replace(/\.$/, ""))
    .filter((t) => t.length > 1);
}

export function parseLabel(text: string): ParsedLabel {
  const allergens = new Set<Allergen>();
  const mayContain = new Set<Allergen>();
  let gluten = false;
  let gelatin = false;
  let pork = false;
  let meat = false;
  let addedSugar = false;
  let sodium = false;

  const tokens: IngredientToken[] = tokenizeIngredients(text).map((raw) => {
    const flags: string[] = [];
    let kind: IngredientToken["kind"] = "clean";
    const crossContact = /may contain|processed in|shared (facility|equipment)/i.test(raw);
    const rank = (k: FlagKind) => {
      const order: (IngredientToken["kind"])[] = ["clean", "info", "dietary", "secondary", "top9"];
      if (order.indexOf(k) > order.indexOf(kind)) kind = k;
    };

    for (const [a, re] of Object.entries(ALLERGEN_PATTERNS) as [Allergen, RegExp][]) {
      if (re.test(raw)) {
        (crossContact ? mayContain : allergens).add(a);
        flags.push(crossContact ? `May contain ${ALLERGEN_LABEL[a]}` : ALLERGEN_LABEL[a]);
        rank(TOP9.includes(a) ? "top9" : "secondary");
      }
    }
    if (GLUTEN.test(raw) && !crossContact) {
      gluten = true;
      flags.push("Gluten");
      rank("dietary");
    }
    if (GELATIN.test(raw)) {
      gelatin = true;
      flags.push("Gelatin");
      rank("secondary");
    }
    if (PORK.test(raw)) {
      pork = true;
      flags.push("Pork");
      rank("dietary");
    }
    if (MEAT.test(raw)) {
      meat = true;
      flags.push("Meat");
      rank("dietary");
    }
    if (SUGAR.test(raw)) {
      addedSugar = true;
      flags.push("Added sugar");
      rank("info");
    }
    if (SODIUM.test(raw)) {
      sodium = true;
      flags.push("Sodium");
      rank("info");
    }
    return { text: raw, kind, flags };
  });

  return {
    tokens,
    allergens: [...allergens],
    mayContain: [...mayContain].filter((a) => !allergens.has(a)),
    gluten,
    gelatin,
    pork,
    meat,
    addedSugar,
    sodium,
  };
}

export interface SafetyTag {
  label: string;
  tone: Tone;
}

/** Automated inventory tags shown on scans and stock. */
export function safetyTags(f: FoodFacts): SafetyTag[] {
  const tags: SafetyTag[] = [];
  const all = new Set([...f.allergens, ...f.mayContain]);
  if (!f.gluten && !all.has("wheat")) tags.push({ label: "Gluten-Free", tone: "safe" });
  if (!all.has("peanut") && !all.has("treenut")) tags.push({ label: "Nut-Free", tone: "safe" });
  if (!all.has("milk")) tags.push({ label: "Dairy-Free", tone: "safe" });
  if (f.halalCertified) tags.push({ label: "Halal Compliant", tone: "safe" });
  if (f.kosherCertified) tags.push({ label: "Kosher Certified", tone: "safe" });
  if (!f.meat && !f.pork && !f.gelatin && !all.has("fish") && !all.has("shellfish"))
    tags.push({ label: "Vegetarian", tone: "safe" });
  if (f.sugarG <= LOW_SUGAR_LIMIT_G) tags.push({ label: "Low Sugar", tone: "info" });

  for (const a of f.allergens) {
    tags.push({
      label: `Contains ${ALLERGEN_LABEL[a]} - Flagged`,
      tone: SECONDARY.includes(a) ? "caution" : "danger",
    });
  }
  for (const a of f.mayContain) tags.push({ label: `May Contain ${ALLERGEN_LABEL[a]}`, tone: "caution" });
  if (f.gelatin) tags.push({ label: "Contains Gelatin - Flagged", tone: "caution" });
  if (f.pork) tags.push({ label: "Contains Pork", tone: "danger" });
  return tags;
}

export function isFlagged(f: FoodFacts): boolean {
  return f.allergens.length > 0 || f.mayContain.length > 0 || f.gelatin || f.gluten;
}

export function profileRestrictionLabels(p: FamilyProfile) {
  return {
    top9: p.allergens.filter((a) => TOP9.includes(a)).map((a) => ALLERGEN_LABEL[a]),
    secondary: p.allergens.filter((a) => SECONDARY.includes(a)).map((a) => ALLERGEN_LABEL[a]),
    conditions: p.conditions.map((c) => CONDITION_LABEL[c]),
    religious: p.religious.map((r) => RELIGIOUS_LABEL[r]),
  };
}

const PII = [
  /[\w.+-]+@[\w-]+\.[\w.]+/, // email
  /(\+?\d[\s-.]?)?\(?\d{3}\)?[\s-.]?\d{3}[\s-.]?\d{4}/, // phone
  /\b\d{3}-\d{2}-\d{4}\b/, // SSN
  /\b\d{1,5}\s+\w+\s+(street|st|avenue|ave|road|rd|blvd|lane|ln|drive|dr)\b/i, // street address
];

/** Notes must stay anonymous: block emails, phone numbers, SSNs and street addresses. */
export function containsPII(text: string): boolean {
  return PII.some((re) => re.test(text));
}

/* ------------------------- Packing gate & slips ------------------------- */

/** Final gate used by the server before an item can enter a box. */
export function canPack(profile: FamilyProfile, item: FoodFacts & { quantity: number }): Verdict {
  if (item.quantity <= 0) return { safe: false, reasons: ["Out of stock"] };
  return evaluateItem(profile, item);
}

/** Exclusion badges printed on a verified packing slip for this family. */
export function verifiedExclusions(p: Pick<FamilyProfile, "allergens" | "conditions" | "religious">): string[] {
  const out: string[] = [];
  if (p.allergens.includes("peanut") || p.allergens.includes("treenut")) out.push("Nut-Free");
  if (p.conditions.includes("celiac") || p.allergens.includes("wheat")) out.push("Gluten-Free / Celiac Safe");
  if (p.allergens.includes("milk")) out.push("Dairy-Free");
  if (p.allergens.includes("egg")) out.push("Egg-Free");
  if (p.allergens.includes("soy")) out.push("Soy-Free");
  if (p.allergens.includes("sesame")) out.push("Sesame-Free");
  if (p.allergens.includes("fish") || p.allergens.includes("shellfish")) out.push("Seafood-Free");
  for (const a of p.allergens) {
    if (SECONDARY.includes(a)) out.push(`${ALLERGEN_LABEL[a]}-Free`);
  }
  if (p.conditions.includes("diabetes")) out.push("Low Sugar");
  if (p.religious.includes("halal")) out.push("Halal Compliant");
  if (p.religious.includes("kosher")) out.push("Kosher Compliant");
  if (p.religious.includes("vegetarian")) out.push("Vegetarian");
  return out;
}

/* ------------------------- Live label analysis ------------------------- */

export type LiveTone = "secondary" | "top9" | "binder" | "safe";
export interface LiveBadge {
  text: string;
  tone: LiveTone;
  why: string;
}

const BINDERS: [RegExp, string][] = [
  [/whey/i, "Milk-derived binder / protein"],
  [/casein|caseinate/i, "Milk protein, even in some 'non-dairy' foods"],
  [/gelatin/i, "Animal-derived binder (often pork or beef)"],
  [/lecithin/i, "Emulsifier, usually soy or sunflower"],
  [/albumin|albumen/i, "Egg-white binder"],
  [/carrageenan|xanthan|guar|agar|pectin/i, "Thickener / binder"],
  [/modified (food )?starch|maltodextrin|dextrin/i, "Starch binder — source grain may vary"],
  [/natural flavou?rs?/i, "Unspecified source — may hide allergens or animal products"],
];

/** Instant, rule-based badges for any typed ingredient text (no AI involved). */
export function liveAnalyze(text: string): LiveBadge[] {
  return tokenizeIngredients(text).map((raw) => {
    for (const a of SECONDARY) {
      if (ALLERGEN_PATTERNS[a].test(raw)) return { text: raw, tone: "secondary", why: `Secondary allergen: ${ALLERGEN_LABEL[a]}` };
    }
    for (const [re, why] of BINDERS) {
      if (re.test(raw)) return { text: raw, tone: "binder", why };
    }
    for (const a of TOP9) {
      if (ALLERGEN_PATTERNS[a].test(raw)) return { text: raw, tone: "top9", why: `Top-9 allergen: ${ALLERGEN_LABEL[a]}` };
    }
    if (GLUTEN.test(raw)) return { text: raw, tone: "top9", why: "Contains gluten" };
    return { text: raw, tone: "safe", why: "No known allergen or binder" };
  });
}
