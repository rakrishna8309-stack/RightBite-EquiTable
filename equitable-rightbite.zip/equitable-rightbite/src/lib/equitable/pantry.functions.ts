import { createServerFn } from "@tanstack/react-start";
import type { SupabaseClient } from "@supabase/supabase-js";
import { z } from "zod";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { Database } from "@/integrations/supabase/types";

import { boxSafetyScore, canPack, containsPII, describeProfile, isFlagged, verifiedExclusions } from "./engine";
import {
  CONDITIONS,
  RELIGIOUS,
  SECONDARY,
  TOP9,
  type Allergen,
  type Condition,
  type FamilyProfile,
  type InventoryItem,
  type PackedLine,
  type PantrySnapshot,
  type Religious,
  type Tone,
} from "./types";

type DB = SupabaseClient<Database>;
type ItemRow = Database["public"]["Tables"]["inventory_items"]["Row"];
type ProfileRow = Database["public"]["Tables"]["family_profiles"]["Row"];

const ALL_ALLERGENS = [...TOP9, ...SECONDARY] as [Allergen, ...Allergen[]];

function toItem(r: ItemRow): InventoryItem {
  return {
    id: r.id,
    name: r.name,
    brand: r.brand,
    category: r.category,
    quantity: r.quantity,
    allergens: r.allergens as Allergen[],
    mayContain: r.may_contain as Allergen[],
    gluten: r.gluten,
    gelatin: r.gelatin,
    meat: r.meat,
    pork: r.pork,
    sugarG: Number(r.sugar_g),
    halalCertified: r.halal_certified,
    kosherCertified: r.kosher_certified,
    ingredients: r.ingredients,
  };
}

function toProfile(r: ProfileRow): FamilyProfile {
  return {
    id: r.id,
    code: r.code,
    summary: r.summary,
    householdSize: r.household_size,
    severity: r.severity as FamilyProfile["severity"],
    allergens: r.allergens as Allergen[],
    conditions: r.conditions as Condition[],
    religious: r.religious as Religious[],
    notes: r.notes,
    status: r.status as FamilyProfile["status"],
  };
}

function fail(error: { message: string } | null, what: string): void {
  if (error) {
    console.error(`[pantry] ${what}:`, error);
    throw new Error(`Could not ${what}. Please try again.`);
  }
}

async function loadPantry(db: DB): Promise<PantrySnapshot> {
  const [items, profiles, lines, slips, activity, counters] = await Promise.all([
    db.from("inventory_items").select("*").order("created_at", { ascending: false }).order("id"),
    db.from("family_profiles").select("*").order("created_at", { ascending: false }),
    db.from("box_lines").select("*").order("added_at"),
    db.from("packing_slips").select("*").order("packed_at", { ascending: false }).limit(20),
    db.from("activity_log").select("*").order("created_at", { ascending: false }).limit(12),
    db.from("pantry_counters").select("*").eq("id", 1).maybeSingle(),
  ]);
  for (const [res, what] of [
    [items, "load inventory"],
    [profiles, "load families"],
    [lines, "load boxes"],
    [slips, "load packing slips"],
    [activity, "load activity"],
    [counters, "load counters"],
  ] as const) fail(res.error, what);

  const boxes: Record<string, PackedLine[]> = {};
  for (const l of lines.data ?? []) {
    (boxes[l.profile_id] ??= []).push({ itemId: l.item_id, name: l.name, brand: l.brand, count: l.count });
  }
  const c = counters.data;
  return {
    inventory: (items.data ?? []).map(toItem),
    profiles: (profiles.data ?? []).map(toProfile),
    boxes,
    slips: (slips.data ?? []).map((s) => ({
      id: s.id,
      profileId: s.profile_id ?? "",
      profileCode: s.profile_code,
      profileSummary: s.profile_summary,
      lines: (s.lines as unknown as PackedLine[]) ?? [],
      safetyScore: s.safety_score,
      exclusions: s.exclusions,
      packedAt: s.packed_at,
    })),
    activity: (activity.data ?? []).map((a) => ({ id: a.id, text: a.text, tone: a.tone as Tone, createdAt: a.created_at })),
    metrics: { scanned: c?.scanned ?? 0, matched: c?.matched ?? 0, intercepted: c?.intercepted ?? 0, boxes: c?.boxes ?? 0 },
  };
}

async function getRows(db: DB, profileId: string, itemId?: string) {
  const profileRes = await db.from("family_profiles").select("*").eq("id", profileId).maybeSingle();
  fail(profileRes.error, "load the family");
  if (!profileRes.data) throw new Error("That family profile no longer exists.");
  let item: InventoryItem | null = null;
  if (itemId) {
    const itemRes = await db.from("inventory_items").select("*").eq("id", itemId).maybeSingle();
    fail(itemRes.error, "load the item");
    if (!itemRes.data) throw new Error("That item is no longer in stock.");
    item = toItem(itemRes.data);
  }
  return { profile: toProfile(profileRes.data), item };
}

export const getPantry = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => loadPantry(context.supabase));

const scannedSchema = z.object({
  name: z.string().trim().min(1).max(120),
  brand: z.string().trim().max(80),
  category: z.string().trim().max(60),
  quantity: z.number().int().min(1).max(10000),
  allergens: z.array(z.enum(ALL_ALLERGENS)),
  mayContain: z.array(z.enum(ALL_ALLERGENS)),
  gluten: z.boolean(),
  gelatin: z.boolean(),
  meat: z.boolean(),
  pork: z.boolean(),
  sugarG: z.number().min(0).max(1000),
  halalCertified: z.boolean(),
  kosherCertified: z.boolean(),
  ingredients: z.string().max(4000),
});

export const addScannedItem = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => scannedSchema.parse(input))
  .handler(async ({ data, context }) => {
    const db = context.supabase;
    const { error } = await db.rpc("add_scanned_item", {
      p_name: data.name,
      p_brand: data.brand || "Unbranded",
      p_category: data.category || "General",
      p_quantity: data.quantity,
      p_allergens: data.allergens,
      p_may_contain: data.mayContain,
      p_gluten: data.gluten,
      p_gelatin: data.gelatin,
      p_meat: data.meat,
      p_pork: data.pork,
      p_sugar_g: data.sugarG,
      p_halal: data.halalCertified,
      p_kosher: data.kosherCertified,
      p_ingredients: data.ingredients,
      p_flagged: isFlagged({ ...data }),
    });
    fail(error, "add the item");
    return loadPantry(db);
  });

const profileSchema = z.object({
  householdSize: z.number().int().min(1).max(20),
  severity: z.enum(["severe", "moderate", "mild"]),
  allergens: z.array(z.enum(ALL_ALLERGENS)),
  conditions: z.array(z.enum(CONDITIONS as [Condition, ...Condition[]])),
  religious: z.array(z.enum(RELIGIOUS as [Religious, ...Religious[]])),
  notes: z.string().max(500),
});

export const addProfile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => profileSchema.parse(input))
  .handler(async ({ data, context }) => {
    if (containsPII(data.notes)) throw new Error("Notes must not include personal details.");
    if (data.allergens.length + data.conditions.length + data.religious.length === 0) {
      throw new Error("Select at least one restriction or requirement.");
    }
    const db = context.supabase;
    let code = "";
    for (let attempt = 0; attempt < 6; attempt++) {
      code = String(1000 + Math.floor(Math.random() * 9000));
      const { error } = await db.from("family_profiles").insert({
        id: `fam-${code}`,
        code,
        summary: describeProfile(data),
        household_size: data.householdSize,
        severity: data.severity,
        allergens: data.allergens,
        conditions: data.conditions,
        religious: data.religious,
        notes: data.notes.trim(),
      });
      if (!error) break;
      if (error.code !== "23505" || attempt === 5) fail(error, "save the family");
    }
    await db.from("activity_log").insert({ text: `New profile added: Family #${code}`, tone: "info" });
    return { code, pantry: await loadPantry(db) };
  });

const idSchema = z.object({ id: z.string().min(1).max(64) });

export const removeProfile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => idSchema.parse(input))
  .handler(async ({ data, context }) => {
    const db = context.supabase;
    // Return any open-box items to stock before the family is deleted.
    const lines = await db.from("box_lines").select("item_id, count").eq("profile_id", data.id);
    fail(lines.error, "load the box");
    for (const l of lines.data ?? []) {
      for (let i = 0; i < l.count; i++) {
        const { error } = await db.rpc("unpack_item", { p_profile: data.id, p_item: l.item_id });
        fail(error, "return items to stock");
      }
    }
    const { error } = await db.from("family_profiles").delete().eq("id", data.id);
    fail(error, "remove the family");
    return loadPantry(db);
  });

export const setProfileStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ id: z.string().min(1).max(64), status: z.enum(["pending", "packed", "picked-up"]) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("family_profiles").update({ status: data.status }).eq("id", data.id);
    fail(error, "update the family");
    return loadPantry(context.supabase);
  });

const boxSchema = z.object({ profileId: z.string().min(1).max(64), itemId: z.string().min(1).max(64) });

export const packItem = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => boxSchema.parse(input))
  .handler(async ({ data, context }) => {
    const db = context.supabase;
    const { profile, item } = await getRows(db, data.profileId, data.itemId);
    // The rule engine is the final gate: unsafe items can never enter a box.
    const verdict = canPack(profile, item!);
    if (!verdict.safe) throw new Error(`Blocked: ${verdict.reasons.join(", ")}`);
    const { error } = await db.rpc("pack_item", { p_profile: data.profileId, p_item: data.itemId });
    fail(error, "pack the item");
    return loadPantry(db);
  });

export const unpackItem = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => boxSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.rpc("unpack_item", { p_profile: data.profileId, p_item: data.itemId });
    fail(error, "remove the item");
    return loadPantry(context.supabase);
  });

export const completeBox = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ profileId: z.string().min(1).max(64) }).parse(input))
  .handler(async ({ data, context }) => {
    const db = context.supabase;
    const { profile } = await getRows(db, data.profileId);
    const lines = await db.from("box_lines").select("item_id, count").eq("profile_id", profile.id);
    fail(lines.error, "load the box");
    const ids = (lines.data ?? []).map((l) => l.item_id);
    const items = ids.length ? await db.from("inventory_items").select("*").in("id", ids) : { data: [], error: null };
    fail(items.error, "load the box items");
    const facts = (lines.data ?? []).flatMap((l) => {
      const row = items.data?.find((i) => i.id === l.item_id);
      return row ? Array<InventoryItem>(l.count).fill(toItem(row)) : [];
    });
    const score = boxSafetyScore(profile, facts);
    if (score < 100) throw new Error("This box contains an item that no longer passes the safety rules. Remove it first.");
    const { data: slipId, error } = await db.rpc("complete_box", {
      p_profile: profile.id,
      p_score: score,
      p_exclusions: verifiedExclusions(profile),
    });
    fail(error, "seal the box");
    return { slipId: slipId as string, pantry: await loadPantry(db) };
  });
