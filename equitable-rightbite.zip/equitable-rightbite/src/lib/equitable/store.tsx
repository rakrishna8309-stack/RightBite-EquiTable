import {
  createContext,
  useContext,
  useEffect,
  useReducer,
  type Dispatch,
  type ReactNode,
} from "react";

import {
  INITIAL_ACTIVITY,
  INITIAL_INVENTORY,
  INITIAL_METRICS,
  INITIAL_PROFILES,
} from "./data";
import { boxSafetyScore, canPack, verifiedExclusions } from "./engine";
import type {
  Activity,
  FamilyProfile,
  InventoryItem,
  PackedLine,
  PackingSlip,
  PantryMetrics,
  PickupStatus,
  Tone,
} from "./types";

export interface EquiTableState {
  inventory: InventoryItem[];
  profiles: FamilyProfile[];
  boxes: Record<string, PackedLine[]>;
  slips: PackingSlip[];
  activity: (Activity & { time?: string })[];
  metrics: PantryMetrics;
  selectedProfileId: string;
}

export const equiTableInitialState: EquiTableState = {
  inventory: INITIAL_INVENTORY,
  profiles: INITIAL_PROFILES,
  boxes: {},
  slips: [],
  activity: INITIAL_ACTIVITY.map((a) => ({
    ...a,
    createdAt: a.createdAt ?? new Date().toISOString(),
  })),
  metrics: INITIAL_METRICS,
  selectedProfileId: INITIAL_PROFILES[0]?.id ?? "",
};

export type EquiTableAction =
  | { type: "hydrate"; state: EquiTableState }
  | { type: "reset" }
  | { type: "selectProfile"; id: string }
  | { type: "addScanned"; item: InventoryItem; flagged: boolean }
  | { type: "addProfile"; profile: FamilyProfile }
  | { type: "removeProfile"; id: string }
  | { type: "markPickedUp"; profileId: string }
  | { type: "setStatus"; profileId: string; status: PickupStatus }
  | { type: "pack"; profileId: string; itemId: string }
  | { type: "unpack"; profileId: string; itemId: string }
  | { type: "complete"; profileId: string; slipId: string };

function logEntry(text: string, tone: Tone): Activity & { time: string } {
  const now = new Date();
  return {
    id: `act-${now.getTime()}-${Math.random().toString(36).slice(2, 6)}`,
    text,
    tone,
    createdAt: now.toISOString(),
    time: now.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }),
  };
}

export function equiTableReducer(
  state: EquiTableState,
  action: EquiTableAction,
): EquiTableState {
  switch (action.type) {
    case "hydrate":
      return action.state;

    case "reset":
      return equiTableInitialState;

    case "selectProfile":
      return { ...state, selectedProfileId: action.id };

    case "addScanned": {
      const { item, flagged } = action;
      const existingIdx = state.inventory.findIndex(
        (x) =>
          x.name.toLowerCase() === item.name.toLowerCase() &&
          x.brand.toLowerCase() === item.brand.toLowerCase(),
      );
      const inventory =
        existingIdx >= 0
          ? state.inventory.map((x, idx) =>
              idx === existingIdx ? { ...x, quantity: x.quantity + item.quantity } : x,
            )
          : [item, ...state.inventory];

      return {
        ...state,
        inventory,
        metrics: {
          ...state.metrics,
          scanned: state.metrics.scanned + item.quantity,
          intercepted: state.metrics.intercepted + (flagged ? item.quantity : 0),
        },
        activity: [
          logEntry(
            flagged
              ? `Flagged ${item.quantity} × ${item.name} — allergen tags applied`
              : `${item.quantity} × ${item.name} scanned and verified`,
            flagged ? "caution" : "safe",
          ),
          ...state.activity,
        ].slice(0, 20),
      };
    }

    case "addProfile":
      return {
        ...state,
        profiles: [action.profile, ...state.profiles],
        selectedProfileId: action.profile.id,
        activity: [
          logEntry(`New profile added: Family #${action.profile.code}`, "info"),
          ...state.activity,
        ].slice(0, 20),
      };

    case "removeProfile": {
      const openLines = state.boxes[action.id] ?? [];
      const inventory = state.inventory.map((inv) => {
        const line = openLines.find((l) => l.itemId === inv.id);
        return line ? { ...inv, quantity: inv.quantity + line.count } : inv;
      });
      const { [action.id]: _removed, ...restBoxes } = state.boxes;
      const profiles = state.profiles.filter((p) => p.id !== action.id);
      return {
        ...state,
        inventory,
        profiles,
        boxes: restBoxes,
        selectedProfileId:
          state.selectedProfileId === action.id
            ? (profiles[0]?.id ?? "")
            : state.selectedProfileId,
      };
    }

    case "markPickedUp":
    case "setStatus": {
      const status: PickupStatus =
        action.type === "markPickedUp" ? "picked-up" : action.status;
      return {
        ...state,
        profiles: state.profiles.map((p) =>
          p.id === action.profileId ? { ...p, status } : p,
        ),
      };
    }

    case "pack": {
      const profile = state.profiles.find((p) => p.id === action.profileId);
      const item = state.inventory.find((i) => i.id === action.itemId);
      if (!profile || !item) return state;

      if (!canPack(profile, item).safe) return state;

      const currentLines = state.boxes[profile.id] ?? [];
      const exists = currentLines.some((l) => l.itemId === item.id);
      const nextLines = exists
        ? currentLines.map((l) =>
            l.itemId === item.id ? { ...l, count: l.count + 1 } : l,
          )
        : [
            ...currentLines,
            { itemId: item.id, name: item.name, brand: item.brand, count: 1 },
          ];

      return {
        ...state,
        inventory: state.inventory.map((i) =>
          i.id === item.id ? { ...i, quantity: i.quantity - 1 } : i,
        ),
        boxes: { ...state.boxes, [profile.id]: nextLines },
      };
    }

    case "unpack": {
      const currentLines = state.boxes[action.profileId] ?? [];
      const target = currentLines.find((l) => l.itemId === action.itemId);
      if (!target) return state;

      const nextLines =
        target.count > 1
          ? currentLines.map((l) =>
              l.itemId === action.itemId ? { ...l, count: l.count - 1 } : l,
            )
          : currentLines.filter((l) => l.itemId !== action.itemId);

      return {
        ...state,
        inventory: state.inventory.map((i) =>
          i.id === action.itemId ? { ...i, quantity: i.quantity + 1 } : i,
        ),
        boxes: { ...state.boxes, [action.profileId]: nextLines },
      };
    }

    case "complete": {
      const profile = state.profiles.find((p) => p.id === action.profileId);
      const lines = state.boxes[action.profileId] ?? [];
      if (!profile || lines.length === 0) return state;

      const facts = lines.flatMap((l) => {
        const inv = state.inventory.find((x) => x.id === l.itemId);
        return inv ? Array<InventoryItem>(l.count).fill(inv) : [];
      });
      const score = boxSafetyScore(profile, facts);
      if (score < 100) return state;

      const slip: PackingSlip = {
        id: action.slipId,
        profileId: profile.id,
        profileCode: profile.code,
        profileSummary: profile.summary,
        lines,
        safetyScore: score,
        exclusions: verifiedExclusions(profile),
        packedAt: new Date().toLocaleString(),
      };
      const { [profile.id]: _cleared, ...restBoxes } = state.boxes;

      return {
        ...state,
        boxes: restBoxes,
        slips: [slip, ...state.slips],
        profiles: state.profiles.map((p) =>
          p.id === profile.id ? { ...p, status: "packed" } : p,
        ),
        metrics: {
          ...state.metrics,
          matched: state.metrics.matched + 1,
          boxes: state.metrics.boxes + 1,
        },
        activity: [
          logEntry(
            `Box packed for Family #${profile.code} — ${score}% compliant`,
            "safe",
          ),
          ...state.activity,
        ].slice(0, 20),
      };
    }

    default:
      return state;
  }
}

const STORAGE_KEY = "equitable:pantry:v1";

const EquiTableContext = createContext<{
  state: EquiTableState;
  dispatch: Dispatch<EquiTableAction>;
} | null>(null);

export function EquiTableProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(equiTableReducer, equiTableInitialState);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as EquiTableState;
        if (Array.isArray(parsed.inventory) && Array.isArray(parsed.profiles)) {
          dispatch({ type: "hydrate", state: parsed });
        }
      }
    } catch {
      // Ignore invalid localStorage state.
    }
  }, []);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      // Ignore quota errors.
    }
  }, [state]);

  return (
    <EquiTableContext.Provider value={{ state, dispatch }}>
      {children}
    </EquiTableContext.Provider>
  );
}

export function useEquiTable() {
  const ctx = useContext(EquiTableContext);
  if (!ctx) {
    throw new Error("useEquiTable must be used inside EquiTableProvider");
  }
  return ctx;
}
