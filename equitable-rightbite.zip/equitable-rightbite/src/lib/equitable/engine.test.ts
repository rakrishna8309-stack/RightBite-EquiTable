import { describe, expect, it } from "vitest";

import { INITIAL_INVENTORY, INITIAL_PROFILES, SAMPLE_SCANS } from "./data";
import { containsPII, evaluateItem, parseLabel } from "./engine";
import { equiTableInitialState, equiTableReducer } from "./store";

const profile = (code: string) => INITIAL_PROFILES.find((p) => p.code === code)!;
const item = (name: string) => INITIAL_INVENTORY.find((i) => i.name === name)!;
const sample = (id: string) => SAMPLE_SCANS.find((s) => s.id === id)!;

describe("label scanner", () => {
  it("finds hidden Lupin and whey (milk) in the Protein Bar", () => {
    const p = parseLabel(sample("A").ingredients);
    expect(p.allergens).toContain("lupin");
    expect(p.allergens).toContain("milk");
  });

  it("does not treat cocoa butter as dairy", () => {
    expect(parseLabel("cocoa butter, sugar").allergens).not.toContain("milk");
  });

  it("finds Mustard and Sulfites in the Vegetable Soup", () => {
    const p = parseLabel(sample("B").ingredients);
    expect(p.allergens).toEqual(expect.arrayContaining(["mustard", "sulfites"]));
    expect(p.sodium).toBe(true);
  });

  it("finds no allergens, gluten or gelatin in the Rice & Beans Pack", () => {
    const p = parseLabel(sample("C").ingredients);
    expect(p.allergens).toEqual([]);
    expect(p.mayContain).toEqual([]);
    expect(p.gluten).toBe(false);
    expect(p.gelatin).toBe(false);
    expect(sample("C").halalCertified).toBe(true);
  });
});

describe("matching rules", () => {
  it("rejects peanut butter for the peanut-anaphylaxis family", () => {
    expect(evaluateItem(profile("1042"), item("Creamy Peanut Butter")).safe).toBe(false);
  });

  it("rejects wheat pasta for a Celiac family", () => {
    expect(evaluateItem(profile("1042"), item("Whole Wheat Penne")).reasons).toContain(
      "Contains gluten (Celiac)",
    );
  });

  it("rejects 'may contain lupin' items for a lupin-allergic family", () => {
    expect(evaluateItem(profile("3317"), item("Granola Clusters")).safe).toBe(false);
  });

  it("rejects hidden gelatin for a Halal family", () => {
    expect(evaluateItem(profile("2089"), item("Fruit Gummy Snacks")).reasons).toContain(
      "Contains Hidden Gelatin",
    );
  });

  it("accepts Halal-certified chicken for a Halal family", () => {
    expect(evaluateItem(profile("2089"), item("Halal Chicken Breast (Canned)")).safe).toBe(true);
  });

  it("rejects items over 10g sugar for a low-sugar family", () => {
    expect(evaluateItem(profile("5204"), item("Shelf-Stable Whole Milk")).safe).toBe(false);
    expect(evaluateItem(profile("5204"), item("Unsweetened Applesauce")).safe).toBe(true);
  });
});

describe("packing", () => {
  it("never lets a rejected item into a box", () => {
    const s = equiTableReducer(equiTableInitialState, {
      type: "pack",
      profileId: "fam-1042",
      itemId: item("Creamy Peanut Butter").id,
    });
    expect(s.boxes["fam-1042"]).toBeUndefined();
  });

  it("packs a safe item and takes it out of stock", () => {
    const id = item("Rice & Beans Pack").id;
    const s = equiTableReducer(equiTableInitialState, { type: "pack", profileId: "fam-1042", itemId: id });
    expect(s.boxes["fam-1042"]?.[0]?.count).toBe(1);
    expect(s.inventory.find((i) => i.id === id)!.quantity).toBe(item("Rice & Beans Pack").quantity - 1);
  });
});

describe("anonymized profiles", () => {
  it("blocks emails and phone numbers in notes", () => {
    expect(containsPII("call 555-123-4567")).toBe(true);
    expect(containsPII("mom@example.com")).toBe(true);
    expect(containsPII("Child carries epinephrine")).toBe(false);
  });
});
