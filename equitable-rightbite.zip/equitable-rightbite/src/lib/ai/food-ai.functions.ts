import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { liveAnalyze, parseLabel } from "../equitable/engine";
import { ALLERGEN_LABEL } from "../equitable/types";
import { buildCombinedGuidance } from "../rightbite/catalog";

export interface Source {
  title: string;
  url: string;
}

export interface IngredientConcern {
  ingredient: string;
  category: "allergen" | "dietary" | "ambiguous";
  severity: "high" | "medium" | "low";
  concern: string;
  affects: string[];
}

export interface IngredientReview {
  summary: string;
  concerns: IngredientConcern[];
  sources: Source[];
}

export interface FoodAnswer {
  answer: string;
  canEat: string[];
  avoid: string[];
  tips: string[];
  sources: Source[];
}

type AiResult<T> = { ok: true; result: T } | { ok: false; error: string };

const restrictionsSchema = z.array(z.string().trim().min(1).max(60)).max(40);

export const reviewIngredients = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z.object({ text: z.string().trim().min(3).max(2000), restrictions: restrictionsSchema }).parse(input),
  )
  .handler(async ({ data }): Promise<AiResult<IngredientReview>> => {
    const parsed = parseLabel(data.text);
    const badges = liveAnalyze(data.text);
    const concerns: IngredientConcern[] = [];

    for (const a of parsed.allergens) {
      concerns.push({
        ingredient: ALLERGEN_LABEL[a],
        category: "allergen",
        severity: "high",
        concern: `Contains ${ALLERGEN_LABEL[a]}.`,
        affects: [ALLERGEN_LABEL[a]],
      });
    }
    for (const b of badges) {
      if (b.tone === "binder") {
        concerns.push({
          ingredient: b.text,
          category: "ambiguous",
          severity: "medium",
          concern: b.why,
          affects: ["Vegetarian", "Halal", "Kosher", "Allergies"],
        });
      }
    }
    if (/enzymes?/i.test(data.text)) {
      concerns.push({
        ingredient: "Enzymes",
        category: "ambiguous",
        severity: "medium",
        concern: "Unspecified 'enzymes' in cheese or baked goods may be calf rennet (animal-derived).",
        affects: ["Vegetarian", "Halal", "Kosher"],
      });
    }

    return {
      ok: true,
      result: {
        summary:
          concerns.length === 0
            ? "No Top-9 allergens, secondary allergens, or ambiguous animal binders detected."
            : `Flagged ${concerns.length} ingredient concern(s) for human review.`,
        concerns,
        sources: [
          {
            title: "U.S. FDA — Food Allergies: What You Need to Know",
            url: "https://www.fda.gov/food/buy-store-serve-safe-food/food-allergies-what-you-need-know",
          },
          {
            title: "Vegetarian Society — Hidden Animal Ingredients in Food",
            url: "https://vegsoc.org/trademarks/how-to-skip-food-labels/",
          },
        ],
      },
    };
  });

export const askFood = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z.object({ question: z.string().trim().min(3).max(500), restrictions: restrictionsSchema }).parse(input),
  )
  .handler(async ({ data }): Promise<AiResult<FoodAnswer>> => {
    const guidance = buildCombinedGuidance(data.restrictions);
    return {
      ok: true,
      result: {
        answer:
          guidance.activeLabels.length > 0
            ? `Combined guidance for ${guidance.activeLabels.join(" + ")}:`
            : "General multi-restriction dietary guidance:",
        canEat: guidance.safeMealIdeas.map((m) => `${m.title}: ${m.items}`),
        avoid: guidance.strictAvoids.slice(0, 8),
        tips: guidance.hiddenTraps.map((t) => `${t.name} — ${t.whatToLookFor}`),
        sources: guidance.sources.map((s) => ({ title: `${s.organization}: ${s.title}`, url: s.url })),
      },
    };
  });
