export interface VerifiedSource {
  title: string;
  organization: string;
  url: string;
}

export type RestrictionGroupKey =
  | "top9"
  | "nonTop9"
  | "intolerances"
  | "diets";

export interface RestrictionOption {
  id: string;
  label: string;
  group: RestrictionGroupKey;
  description: string;
  hiddenTerms: string[];
  safeSwaps: string[];
  avoidFoods: string[];
  sources: VerifiedSource[];
}

export interface HiddenIngredientEntry {
  id: string;
  name: string;
  aliases: string[];
  commonProducts: string[];
  affects: string[];
  severity: "high" | "medium";
  plainExplanation: string;
  whatToLookFor: string;
  sources: VerifiedSource[];
}

export const RESTRICTION_SECTIONS: {
  key: RestrictionGroupKey;
  title: string;
  subtitle: string;
}[] = [
  {
    key: "top9",
    title: "1. FDA Top-9 Major Allergens",
    subtitle: "Required to be bolded or listed in 'Contains:' statements on U.S. labels.",
  },
  {
    key: "nonTop9",
    title: "2. Secondary & Non-Regulated Allergens",
    subtitle: "Common triggers in the U.S. that do NOT require bold 'Contains:' callouts.",
  },
  {
    key: "intolerances",
    title: "3. Food Intolerances & Sensitivities",
    subtitle: "Digestive or metabolic triggers often hidden in seasonings and thickeners.",
  },
  {
    key: "diets",
    title: "4. Lifestyle, Medical & Religious Diets",
    subtitle: "Ethical, religious, or clinical rules affected by processing aids and enzymes.",
  },
];

const SRC = {
  fdaTop9: {
    title: "Food Allergies — What You Need to Know",
    organization: "U.S. FDA",
    url: "https://www.fda.gov/food/buy-store-serve-safe-food/food-allergies-what-you-need-know",
  },
  fdaLupin: {
    title: "Consumer Advice on Lupin",
    organization: "U.S. FDA",
    url: "https://www.fda.gov/food/food-additives-petitions/consumer-advice-lupin",
  },
  allergyLupin: {
    title: "Lupin Food Allergy & Cross-Reactivity",
    organization: "Allergy & Asthma Network",
    url: "https://allergyasthmanetwork.org/news/why-lupin-allergy-becoming-more-common/",
  },
  vegSoc: {
    title: "Common Hidden Animal Ingredients in Food",
    organization: "Vegetarian Society",
    url: "https://vegsoc.org/trademarks/how-to-skip-food-labels/",
  },
  utorontoVeg: {
    title: "Defining Vegetarian & Hidden Slaughter Byproducts",
    organization: "University of Toronto Food Services",
    url: "https://foodservices.utoronto.ca/vegetarian/",
  },
  celiac: {
    title: "Sources of Gluten",
    organization: "Celiac Disease Foundation",
    url: "https://celiac.org/gluten-free-living/what-is-gluten/sources-of-gluten/",
  },
} satisfies Record<string, VerifiedSource>;

export const RESTRICTION_OPTIONS: RestrictionOption[] = [
  {
    id: "peanut",
    label: "Peanut",
    group: "top9",
    description: "Strict avoidance of peanuts, arachis oil, and shared-line snacks.",
    hiddenTerms: ["arachis", "groundnut", "mandelonas", "lupin (cross-reactive legume)"],
    safeSwaps: ["SunButter (sunflower seed butter)", "Pumpkin seed butter", "Oat-based granola"],
    avoidFoods: ["Mixed nuts", "Trail mixes", "Thai/satay sauces", "Unlabeled bakery cookies"],
    sources: [SRC.fdaTop9, SRC.fdaLupin],
  },
  {
    id: "treenut",
    label: "Tree Nuts",
    group: "top9",
    description: "Almond, cashew, walnut, pecan, hazelnut, pistachio, macadamia, Brazil nut.",
    hiddenTerms: ["marzipan", "gianduja", "praline", "frangipane", "nut oils"],
    safeSwaps: ["Roasted chickpeas", "Pumpkin & sunflower seeds", "Oat milk or soy milk"],
    avoidFoods: ["Pesto (pine nuts/walnuts)", "Almond flour baked goods", "Nut milks & nut cheeses"],
    sources: [SRC.fdaTop9],
  },
  {
    id: "milk",
    label: "Dairy / Milk",
    group: "top9",
    description: "All cow, goat, and sheep milk proteins (whey, casein, lactose).",
    hiddenTerms: ["whey", "casein", "sodium caseinate", "ghee", "lactalbumin", "milk solids"],
    safeSwaps: ["Nutritional yeast (for cheesy flavor)", "Oat/soy/coconut yogurt", "Olive oil"],
    avoidFoods: ["Cheese-dusted chips", "'Non-dairy' creamers with caseinate", "Milk chocolate"],
    sources: [SRC.fdaTop9],
  },
  {
    id: "egg",
    label: "Egg",
    group: "top9",
    description: "Egg whites, yolks, albumin, and egg-derived binders.",
    hiddenTerms: ["albumin", "albumen", "lysozyme (E1105)", "ovalbumin", "mayonnaise"],
    safeSwaps: ["Flax eggs", "Aquafaba (chickpea brine)", "Egg-free pasta"],
    avoidFoods: ["Traditional brioche/challah", "Fresh egg pasta", "Some aged cheeses (lysozyme)"],
    sources: [SRC.fdaTop9],
  },
  {
    id: "wheat",
    label: "Wheat",
    group: "top9",
    description: "Wheat flour, semolina, durum, spelt, farro, kamut, couscous.",
    hiddenTerms: ["semolina", "durum", "spelt", "farina", "hydrolyzed wheat protein"],
    safeSwaps: ["100% corn tortillas", "Brown/white rice", "Quinoa", "Certified GF oats"],
    avoidFoods: ["Standard bread & pasta", "Soy sauce (unless Tamari)", "Breaded snacks"],
    sources: [SRC.fdaTop9, SRC.celiac],
  },
  {
    id: "soy",
    label: "Soy",
    group: "top9",
    description: "Soybeans, tofu, edamame, tempeh, textured vegetable protein (TVP).",
    hiddenTerms: ["edamame", "TVP", "miso", "tamari", "soy lecithin"],
    safeSwaps: ["Coconut aminos", "Chickpeas & lentils", "Sunflower lecithin"],
    avoidFoods: ["Veggie burgers with TVP", "Standard soy sauce", "Many commercial snack bars"],
    sources: [SRC.fdaTop9],
  },
  {
    id: "sesame",
    label: "Sesame",
    group: "top9",
    description: "Sesame seeds, tahini, sesame oil, halvah.",
    hiddenTerms: ["tahini", "benne", "gingelly", "sesamol", "halvah"],
    safeSwaps: ["Pumpkin seed butter", "Avocado or olive oil spreads", "Plain corn chips"],
    avoidFoods: ["Hummus (contains tahini)", "Seeded burger buns", "Everything bagel seasoning"],
    sources: [SRC.fdaTop9],
  },
  {
    id: "fish",
    label: "Fish",
    group: "top9",
    description: "Finned fish including tuna, salmon, cod, anchovies.",
    hiddenTerms: ["anchovy paste", "worcestershire sauce", "fish sauce", "isinglass"],
    safeSwaps: ["Seaweed/kelp flakes", "Mushroom broth", "Vegan Worcestershire"],
    avoidFoods: ["Caesar dressing", "Traditional Worcestershire sauce", "Pad Thai with fish sauce"],
    sources: [SRC.fdaTop9, SRC.vegSoc],
  },
  {
    id: "shellfish",
    label: "Shellfish",
    group: "top9",
    description: "Crustaceans (shrimp, crab, lobster) and mollusks.",
    hiddenTerms: ["glucosamine", "shrimp paste", "oyster sauce", "krill"],
    safeSwaps: ["Mushroom oyster sauce", "Hearts of palm", "Jackfruit"],
    avoidFoods: ["Kimchi with shrimp paste", "Oyster-sauce stir-fries", "Seafood broths"],
    sources: [SRC.fdaTop9],
  },
  {
    id: "lupin",
    label: "Lupin / Lupini",
    group: "nonTop9",
    description: "Legume flour heavily used in gluten-free breads, pastas, and protein bars.",
    hiddenTerms: ["lupin flour", "lupine", "lupini beans", "altramuz", "tarwi"],
    safeSwaps: ["Rice flour", "Chickpea flour", "Certified GF oat flour"],
    avoidFoods: ["Imported European GF pastries", "High-protein GF pastas", "Lupin snack beans"],
    sources: [SRC.fdaLupin, SRC.allergyLupin],
  },
  {
    id: "mustard",
    label: "Mustard",
    group: "nonTop9",
    description: "Mustard seed, mustard powder, and hidden spice-blend mustard.",
    hiddenTerms: ["mustard flour", "sinapis", "unspecified 'spices'"],
    safeSwaps: ["Horseradish", "Turmeric + vinegar", "Plain olive oil & lemon"],
    avoidFoods: ["Vinaigrettes & mayo", "Curry powders", "Pickles & relish"],
    sources: [SRC.fdaTop9],
  },
  {
    id: "sulfites",
    label: "Sulfites",
    group: "nonTop9",
    description: "Preservatives in dried fruits, canned soups, wine, and bottled lemon juice.",
    hiddenTerms: ["potassium metabisulfite", "sodium bisulfite", "sulfur dioxide (E220)"],
    safeSwaps: ["Unsulfured organic dried fruit", "Fresh squeezed citrus", "Fresh soups"],
    avoidFoods: ["Bright orange dried apricots", "Bottled lime/lemon juice", "Conventional wines"],
    sources: [SRC.fdaTop9],
  },
  {
    id: "seeds",
    label: "Seeds (Sunflower / Poppy / Flax)",
    group: "nonTop9",
    description: "Non-sesame seeds common in crackers, breads, and nut-free spreads.",
    hiddenTerms: ["helianthus", "linseed (flax)", "pepitas (pumpkin)", "chia"],
    safeSwaps: ["Oatmeal & rice cakes", "Chickpea snacks", "Olive oil hummus"],
    avoidFoods: ["Multigrain breads", "Seed crackers", "SunButter"],
    sources: [SRC.fdaTop9],
  },
  {
    id: "lactose",
    label: "Lactose Intolerance",
    group: "intolerances",
    description: "Sensitivity to milk sugar (lactose) in fresh dairy and snack seasonings.",
    hiddenTerms: ["milk powder", "whey", "lactose monohydrate", "buttermilk solids"],
    safeSwaps: ["Lactose-free milk", "Aged hard cheeses (naturally near-zero lactose)", "Oat milk"],
    avoidFoods: ["Ice cream", "Cream soups", "Cheese-flavored chips with whey powder"],
    sources: [SRC.fdaTop9],
  },
  {
    id: "celiac",
    label: "Celiac / Strict Gluten-Free",
    group: "intolerances",
    description: "Zero wheat, barley, rye, malt, or cross-contaminated oats.",
    hiddenTerms: ["barley malt", "malt extract", "brewer's yeast", "rye", "triticale"],
    safeSwaps: ["Certified GF oats", "Rice, quinoa, buckwheat, corn", "Potatoes & legumes"],
    avoidFoods: ["Rice Krispies with barley malt", "Regular oats", "Soy sauce"],
    sources: [SRC.celiac],
  },
  {
    id: "lowfodmap",
    label: "Low-FODMAP / IBS",
    group: "intolerances",
    description: "Limits fermentable carbs like onion, garlic, inulin/chicory root, and high-fructose corn syrup.",
    hiddenTerms: ["inulin", "chicory root fiber", "garlic powder", "onion powder", "HFCS"],
    safeSwaps: ["Garlic-infused olive oil", "Chives & green onion tops", "Rice, oats, berries"],
    avoidFoods: ["Fiber bars with chicory root", "Seasoned chips with onion/garlic powder", "Apples"],
    sources: [SRC.fdaTop9],
  },
  {
    id: "vegetarian",
    label: "Vegetarian (Lacto-Ovo)",
    group: "diets",
    description: "No meat, poultry, fish, seafood, or slaughterhouse byproducts (rennet, gelatin, lard).",
    hiddenTerms: ["animal rennet / 'enzymes'", "gelatin", "carmine (E120)", "lard", "isinglass"],
    safeSwaps: ["Microbial-rennet cheeses", "Agar/pectin gummies", "Annatto/beetroot coloring"],
    avoidFoods: ["Cheese chips made with animal rennet", "Marshmallows/gummies", "Red candy with carmine"],
    sources: [SRC.vegSoc, SRC.utorontoVeg],
  },
  {
    id: "vegan",
    label: "Vegan (100% Plant-Based)",
    group: "diets",
    description: "Zero meat, dairy, eggs, honey, insect glazes, or animal processing aids.",
    hiddenTerms: ["whey", "casein", "shellac (E904)", "L-cysteine (E920)", "vitamin D3 (lanolin)"],
    safeSwaps: ["Nutritional yeast", "Carnauba wax candy", "Lichen-derived Vitamin D3"],
    avoidFoods: ["Cheese-flavored snacks", "Glossy coated candies (shellac)", "Commercial bagels with L-cysteine"],
    sources: [SRC.vegSoc, SRC.utorontoVeg],
  },
  {
    id: "halal",
    label: "Halal",
    group: "diets",
    description: "No pork, alcohol extracts, or non-Halal animal gelatin/enzymes.",
    hiddenTerms: ["porcine gelatin", "lard", "vanilla extract (alcohol)", "unverified enzymes"],
    safeSwaps: ["Halal-certified meat", "Fish/plant gelatin", "Alcohol-free vanilla"],
    avoidFoods: ["Standard fruit gummies", "Marshmallows", "Dishes cooked with wine"],
    sources: [SRC.utorontoVeg],
  },
  {
    id: "kosher",
    label: "Kosher",
    group: "diets",
    description: "No pork, shellfish, meat-dairy mixing, or uncertified animal rennet/gelatin.",
    hiddenTerms: ["shellfish", "pork", "non-kosher rennet", "unverified gelatin"],
    safeSwaps: ["OU / OK / Star-K certified items", "Pareve snacks", "Plant-based proteins"],
    avoidFoods: ["Shellfish", "Uncertified cheeses", "Mixed meat-and-dairy snacks"],
    sources: [SRC.utorontoVeg],
  },
  {
    id: "lowsugar",
    label: "Low Sugar / Diabetic-Friendly",
    group: "diets",
    description: "Limits added sugars, syrups, and high-glycemic sweeteners (<= 10g sugar/serving).",
    hiddenTerms: ["maltodextrin", "dextrose", "evaporated cane juice", "brown rice syrup"],
    safeSwaps: ["Plain nuts/seeds", "Unsweetened beans & grains", "High-fiber vegetables"],
    avoidFoods: ["Sweetened cereals", "Fruit gummies", "Sugary protein bars"],
    sources: [SRC.fdaTop9],
  },
];

export const HIDDEN_INGREDIENTS: HiddenIngredientEntry[] = [
  {
    id: "animal-rennet",
    name: "Animal Rennet (Often Listed Simply as 'Enzymes')",
    aliases: ["rennet", "enzymes", "animal enzymes", "calf rennet"],
    commonProducts: [
      "Cheese-flavored tortilla & potato chips (e.g., nacho/cheddar seasonings)",
      "Parmesan, Pecorino Romano, Gorgonzola, and traditional cheddar",
      "Frozen cheese pizzas and boxed mac & cheese",
    ],
    affects: ["Vegetarian", "Halal", "Kosher"],
    severity: "high",
    plainExplanation:
      "Traditional rennet is an enzyme harvested from the stomach lining of slaughtered calves to curdle milk. On U.S. ingredient labels, manufacturers are allowed to list it generically as 'enzymes' without specifying whether it came from animals or microbes.",
    whatToLookFor:
      "Look for 'microbial enzymes', 'vegetable rennet', or a Vegetarian / Kosher symbol—otherwise 'enzymes' in cheese powder may be animal-derived.",
    sources: [SRC.utorontoVeg, SRC.vegSoc],
  },
  {
    id: "carmine",
    name: "Carmine / Cochineal Extract (E120)",
    aliases: ["carmine", "cochineal", "cochineal extract", "crimson lake", "E120", "natural red 4"],
    commonProducts: [
      "Red and pink candies, fruit snacks, and cake frostings",
      "Strawberry yogurts and red fruit juices",
    ],
    affects: ["Vegetarian", "Vegan", "Halal", "Kosher"],
    severity: "high",
    plainExplanation:
      "Carmine is a bright red pigment made by crushing dried female cochineal insects. Because it is 'natural', it frequently appears in products marketed without artificial dyes.",
    whatToLookFor:
      "FDA requires carmine/cochineal to be named on labels—choose products colored with beet juice, annatto, or beta-carotene instead.",
    sources: [SRC.vegSoc],
  },
  {
    id: "gelatin",
    name: "Gelatin (Pork or Beef Collagen)",
    aliases: ["gelatin", "gelatine", "hydrolyzed collagen"],
    commonProducts: [
      "Gummy candies, fruit snacks, and marshmallows",
      "Frosted cereals, whipped yogurts, and gel capsules",
    ],
    affects: ["Vegetarian", "Vegan", "Halal", "Kosher"],
    severity: "high",
    plainExplanation:
      "Gelatin is boiled from animal skin, bones, and connective tissue—most commonly pigskin in North America unless explicitly certified Halal, Kosher, or fish-derived.",
    whatToLookFor:
      "Swap for snacks made with fruit pectin, agar-agar, or carrageenan.",
    sources: [SRC.vegSoc, SRC.utorontoVeg],
  },
  {
    id: "l-cysteine",
    name: "L-Cysteine (E920) Dough Conditioner",
    aliases: ["L-cysteine", "cysteine", "E920"],
    commonProducts: [
      "Mass-produced bagels, pizza crusts, burger buns, and tortillas",
    ],
    affects: ["Vegetarian", "Vegan", "Halal"],
    severity: "medium",
    plainExplanation:
      "L-cysteine softens commercial dough and speeds up industrial baking. While microbial fermentation versions exist, low-cost supplies can be extracted from poultry feathers or animal hair, and labels rarely state the source.",
    whatToLookFor:
      "Choose artisan breads with simple ingredients (flour, water, yeast, salt) or certified vegan/kosher baked goods.",
    sources: [SRC.vegSoc],
  },
  {
    id: "shellac",
    name: "Shellac / Confectioner's Glaze (E904)",
    aliases: ["shellac", "confectioner's glaze", "resinous glaze", "candy glaze", "E904"],
    commonProducts: [
      "Shiny jelly beans, chocolate-coated candies, and sprinkles",
      "Wax coatings on conventional apples and citrus",
    ],
    affects: ["Vegan"],
    severity: "medium",
    plainExplanation:
      "Confectioner's glaze is shellac—a resin secreted by the female lac beetle to create a hard, glossy shell on candies.",
    whatToLookFor:
      "Look for candies glazed with carnauba wax (plant-derived) instead of confectioner's glaze.",
    sources: [SRC.vegSoc, SRC.utorontoVeg],
  },
  {
    id: "lupin-flour",
    name: "Lupin Flour (Hidden Peanut Cross-Reactor)",
    aliases: ["lupin", "lupine", "lupini", "lupin flour", "lupin protein"],
    commonProducts: [
      "Gluten-free breads, cookies, and high-protein pastas",
      "Imported European snacks and plant-based protein bars",
    ],
    affects: ["Peanut", "Lupin / Lupini"],
    severity: "high",
    plainExplanation:
      "Lupin is a legume in the same family as peanuts and triggers severe reactions in many peanut-allergic people. Unlike the Top-9 allergens, U.S. law does not require a bold 'Contains: Lupin' warning.",
    whatToLookFor:
      "Always scan the full ingredient list of gluten-free and keto baked goods for 'lupin' or 'lupine'.",
    sources: [SRC.fdaLupin, SRC.allergyLupin],
  },
];

export interface CombinedGuidance {
  activeLabels: string[];
  safeMealIdeas: { title: string; items: string; whySafe: string }[];
  strictAvoids: string[];
  hiddenTraps: HiddenIngredientEntry[];
  sources: VerifiedSource[];
}

export function buildCombinedGuidance(selectedIds: string[]): CombinedGuidance {
  const selected = RESTRICTION_OPTIONS.filter((o) => selectedIds.includes(o.id));
  const has = (id: string) => selectedIds.includes(id);

  const noMeat = has("vegetarian") || has("vegan");
  const noDairy = has("milk") || has("vegan") || has("lactose");
  const noGluten = has("wheat") || has("celiac");
  const noNuts = has("peanut") || has("treenut");
  const noSoy = has("soy");
  const noSeeds = has("seeds");
  const lowSugar = has("lowsugar");

  const safeMealIdeas: CombinedGuidance["safeMealIdeas"] = [];

  if (!noGluten) {
    safeMealIdeas.push({
      title: "100% Corn Tortilla Black Bean & Avocado Tacos",
      items: "Certified corn tortillas, black beans, salsa, avocado, cilantro, lime",
      whySafe:
        "Naturally free of meat, dairy, eggs, peanuts, tree nuts, soy, sesame, and lupin.",
    });
  } else {
    safeMealIdeas.push({
      title: "Brown Rice, Black Bean & Roasted Veggie Bowl",
      items: "Plain brown or white rice, black beans or lentils, olive oil, cumin, sea salt",
      whySafe:
        "100% gluten-free, nut-free, dairy-free, vegan, Halal, and Kosher-friendly.",
    });
  }

  if (!noSeeds && !noNuts) {
    safeMealIdeas.push({
      title: "Sunflower Seed Butter & Oat Crunch Bowl",
      items: "Certified GF rolled oats, SunButter, cinnamon, chia seeds, berries",
      whySafe: "Delivers protein without peanuts, tree nuts, dairy, or animal enzymes.",
    });
  } else {
    safeMealIdeas.push({
      title: "Crispy Roasted Chickpea & Quinoa Harvest Bowl",
      items: "Quinoa, roasted chickpeas, olive oil, lemon juice, cucumber, herbs",
      whySafe: "Nut-free, seed-free, gluten-free, and plant-based complete protein.",
    });
  }

  if (!noDairy && !noMeat) {
    safeMealIdeas.push({
      title: "Microbial-Rennet Cheddar & Rice Crackers",
      items: "Vegetarian-certified cheddar (microbial enzymes), plain brown rice crackers",
      whySafe: "Avoids animal rennet while keeping dairy protein.",
    });
  } else if (!noSoy) {
    safeMealIdeas.push({
      title: "Edamame, Rice Noodle & Ginger Stir-Fry",
      items: "100% rice noodles, shelled edamame, broccoli, ginger, coconut aminos",
      whySafe: "Dairy-free, egg-free, nut-free, gluten-free, and high-protein.",
    });
  }

  if (!lowSugar) {
    safeMealIdeas.push({
      title: "Unsweetened Applesauce & Certified GF Oat Muffin",
      items: "GF oats, unsweetened applesauce, baking soda, cinnamon, olive oil",
      whySafe: "Zero eggs, dairy, nuts, lupin flour, or L-cysteine dough conditioners.",
    });
  }

  const strictAvoids = Array.from(
    new Set(selected.flatMap((s) => [...s.avoidFoods, ...s.hiddenTerms.slice(0, 2)])),
  );

  const activeLabelSet = new Set(selected.map((s) => s.label));
  const hiddenTraps = HIDDEN_INGREDIENTS.filter((h) =>
    h.affects.some(
      (a) =>
        activeLabelSet.has(a) ||
        (a === "Vegetarian" && noMeat) ||
        (a === "Vegan" && has("vegan")) ||
        (a === "Peanut" && has("peanut")),
    ),
  );

  const seenUrls = new Set<string>();
  const sources = [
    ...selected.flatMap((s) => s.sources),
    ...hiddenTraps.flatMap((h) => h.sources),
  ].filter((src) => !seenUrls.has(src.url) && seenUrls.add(src.url));

  return {
    activeLabels: selected.map((s) => s.label),
    safeMealIdeas,
    strictAvoids,
    hiddenTraps: hiddenTraps.length ? hiddenTraps : HIDDEN_INGREDIENTS.slice(0, 3),
    sources: sources.length ? sources : [SRC.fdaTop9, SRC.vegSoc],
  };
}
