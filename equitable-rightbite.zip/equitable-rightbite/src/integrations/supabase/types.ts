export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      activity_log: {
        Row: {
          created_at: string
          id: string
          text: string
          tone: string
        }
        Insert: {
          created_at?: string
          id?: string
          text: string
          tone?: string
        }
        Update: {
          created_at?: string
          id?: string
          text?: string
          tone?: string
        }
        Relationships: []
      }
      box_lines: {
        Row: {
          added_at: string
          brand: string
          count: number
          item_id: string
          name: string
          profile_id: string
        }
        Insert: {
          added_at?: string
          brand: string
          count?: number
          item_id: string
          name: string
          profile_id: string
        }
        Update: {
          added_at?: string
          brand?: string
          count?: number
          item_id?: string
          name?: string
          profile_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "box_lines_item_id_fkey"
            columns: ["item_id"]
            isOneToOne: false
            referencedRelation: "inventory_items"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "box_lines_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: false
            referencedRelation: "family_profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      family_profiles: {
        Row: {
          allergens: string[]
          code: string
          conditions: string[]
          created_at: string
          household_size: number
          id: string
          notes: string
          religious: string[]
          severity: string
          status: string
          summary: string
        }
        Insert: {
          allergens?: string[]
          code: string
          conditions?: string[]
          created_at?: string
          household_size?: number
          id?: string
          notes?: string
          religious?: string[]
          severity?: string
          status?: string
          summary?: string
        }
        Update: {
          allergens?: string[]
          code?: string
          conditions?: string[]
          created_at?: string
          household_size?: number
          id?: string
          notes?: string
          religious?: string[]
          severity?: string
          status?: string
          summary?: string
        }
        Relationships: []
      }
      inventory_items: {
        Row: {
          allergens: string[]
          brand: string
          category: string
          created_at: string
          gelatin: boolean
          gluten: boolean
          halal_certified: boolean
          id: string
          ingredients: string
          kosher_certified: boolean
          may_contain: string[]
          meat: boolean
          name: string
          pork: boolean
          quantity: number
          sugar_g: number
        }
        Insert: {
          allergens?: string[]
          brand?: string
          category?: string
          created_at?: string
          gelatin?: boolean
          gluten?: boolean
          halal_certified?: boolean
          id?: string
          ingredients?: string
          kosher_certified?: boolean
          may_contain?: string[]
          meat?: boolean
          name: string
          pork?: boolean
          quantity?: number
          sugar_g?: number
        }
        Update: {
          allergens?: string[]
          brand?: string
          category?: string
          created_at?: string
          gelatin?: boolean
          gluten?: boolean
          halal_certified?: boolean
          id?: string
          ingredients?: string
          kosher_certified?: boolean
          may_contain?: string[]
          meat?: boolean
          name?: string
          pork?: boolean
          quantity?: number
          sugar_g?: number
        }
        Relationships: []
      }
      packing_slips: {
        Row: {
          exclusions: string[]
          id: string
          lines: Json
          packed_at: string
          profile_code: string
          profile_id: string | null
          profile_summary: string
          safety_score: number
          volunteer_id: string | null
        }
        Insert: {
          exclusions?: string[]
          id?: string
          lines?: Json
          packed_at?: string
          profile_code: string
          profile_id?: string | null
          profile_summary?: string
          safety_score?: number
          volunteer_id?: string | null
        }
        Update: {
          exclusions?: string[]
          id?: string
          lines?: Json
          packed_at?: string
          profile_code?: string
          profile_id?: string | null
          profile_summary?: string
          safety_score?: number
          volunteer_id?: string | null
        }
        Relationships: []
      }
      pantry_counters: {
        Row: {
          boxes: number
          id: number
          intercepted: number
          matched: number
          scanned: number
        }
        Insert: {
          boxes?: number
          id?: number
          intercepted?: number
          matched?: number
          scanned?: number
        }
        Update: {
          boxes?: number
          id?: number
          intercepted?: number
          matched?: number
          scanned?: number
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      add_scanned_item: {
        Args: {
          p_allergens: string[]
          p_brand: string
          p_category: string
          p_flagged: boolean
          p_gelatin: boolean
          p_gluten: boolean
          p_halal: boolean
          p_ingredients: string
          p_kosher: boolean
          p_may_contain: string[]
          p_meat: boolean
          p_name: string
          p_pork: boolean
          p_quantity: number
          p_sugar_g: number
        }
        Returns: string
      }
      complete_box: {
        Args: { p_exclusions: string[]; p_profile: string; p_score: number }
        Returns: string
      }
      pack_item: {
        Args: { p_item: string; p_profile: string }
        Returns: undefined
      }
      unpack_item: {
        Args: { p_item: string; p_profile: string }
        Returns: undefined
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
