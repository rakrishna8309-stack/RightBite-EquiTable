import { Link } from "@tanstack/react-router";
import {
  ArrowLeftRight,
  LayoutDashboard,
  PackageCheck,
  ScanLine,
  ShieldCheck,
  Users,
} from "lucide-react";
import type { ReactNode } from "react";

import { useEquiTable } from "@/lib/equitable/store";

const NAV = [
  { to: "/equitable", label: "Ops Dashboard", icon: LayoutDashboard },
  { to: "/intake", label: "Inventory Intake", icon: ScanLine },
  { to: "/packing", label: "Box Packing", icon: PackageCheck },
  { to: "/profiles", label: "Client Profiles", icon: Users },
] as const;

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <Link to="/" className="flex items-center gap-2.5">
      <span className="grid size-9 place-items-center rounded-xl bg-brand-gradient text-on-strong shadow-lift">
        <ShieldCheck className="size-5" aria-hidden />
      </span>
      {!compact && (
        <span className="leading-tight">
          <span className="block font-display text-lg font-bold tracking-tight">EquiTable</span>
          <span className="block text-[11px] text-sidebar-muted">Business &amp; Pantry Ops</span>
        </span>
      )}
    </Link>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const { state } = useEquiTable();
  const pending = state.profiles.filter((p) => p.status === "pending").length;

  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[250px_1fr]">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded-md focus:bg-card focus:px-4 focus:py-2"
      >
        Skip to content
      </a>

      {/* Desktop sidebar */}
      <aside className="hidden lg:flex sticky top-0 h-screen flex-col bg-sidebar text-sidebar-foreground">
        <div className="px-5 py-5 border-b border-sidebar-border">
          <Logo />
        </div>
        <nav aria-label="Main" className="flex-1 px-3 py-4 space-y-1">
          {NAV.map(({ to, label, icon: Icon }) => (
            <Link
              key={to}
              to={to}
              activeOptions={{ exact: to === "/equitable" }}
              className="group flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-sidebar-muted transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground data-[status=active]:bg-sidebar-accent data-[status=active]:text-sidebar-accent-foreground"
            >
              <Icon className="size-[18px] group-data-[status=active]:text-sidebar-primary" aria-hidden />
              <span className="flex-1">{label}</span>
              {to === "/packing" && pending > 0 && (
                <span className="rounded-full bg-sidebar-primary px-2 py-0.5 text-[11px] font-bold text-sidebar-primary-foreground">
                  {pending}
                </span>
              )}
            </Link>
          ))}
        </nav>

        <div className="px-3 pb-2">
          <Link
            to="/rightbite"
            className="flex items-center justify-center gap-2 rounded-lg border border-sidebar-border bg-sidebar-accent/40 px-3 py-2 text-xs font-semibold text-sidebar-foreground transition-colors hover:bg-sidebar-accent"
          >
            <ArrowLeftRight className="size-3.5 text-sidebar-primary" aria-hidden />
            Switch to RightBite (Consumer)
          </Link>
        </div>

        <div className="m-3 rounded-xl border border-sidebar-border bg-sidebar-accent/50 p-3.5 text-xs text-sidebar-muted">
          <p className="flex items-center gap-1.5 font-semibold text-sidebar-foreground">
            <ShieldCheck className="size-3.5 text-sidebar-primary" aria-hidden />
            Zero-PII by design
          </p>
          <p className="mt-1">Families are tracked by anonymous ID only.</p>
        </div>
        <p className="px-5 pb-4 text-[11px] text-sidebar-muted">
          Made by Ramakrishna Krishna &amp; Brandon Chae
        </p>
      </aside>

      {/* Mobile top bar */}
      <header className="lg:hidden sticky top-0 z-40 bg-sidebar text-sidebar-foreground">
        <div className="flex items-center justify-between px-4 py-3">
          <Logo />
          <Link
            to="/rightbite"
            className="inline-flex items-center gap-1.5 rounded-lg border border-sidebar-border px-2.5 py-1 text-xs font-semibold text-sidebar-foreground"
          >
            <ArrowLeftRight className="size-3" /> RightBite
          </Link>
        </div>
        <nav aria-label="Main" className="flex gap-1 overflow-x-auto px-2 pb-2">
          {NAV.map(({ to, label, icon: Icon }) => (
            <Link
              key={to}
              to={to}
              activeOptions={{ exact: to === "/equitable" }}
              className="flex shrink-0 items-center gap-2 rounded-lg px-3 py-2 text-xs font-medium text-sidebar-muted data-[status=active]:bg-sidebar-accent data-[status=active]:text-sidebar-accent-foreground"
            >
              <Icon className="size-4" aria-hidden />
              {label}
            </Link>
          ))}
        </nav>
      </header>

      <div className="flex min-w-0 flex-col">
        <main id="main" className="flex-1 px-4 py-5 sm:px-6 lg:px-8 lg:py-6">
          <div className="mx-auto max-w-7xl">{children}</div>
        </main>
        <footer className="border-t px-4 py-4 text-center text-xs text-muted-foreground sm:px-6 lg:px-8">
          EquiTable — Intelligent Dietary Matching &amp; Emergency Food Inventory System · Created by
          Ramakrishna Krishna and Brandon Chae
        </footer>
      </div>
    </div>
  );
}

export function PageHeader({
  eyebrow,
  title,
  description,
  actions,
}: {
  eyebrow: string;
  title: string;
  description?: string;
  actions?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between animate-rise">
      <div>
        <p className="text-xs font-semibold uppercase tracking-[0.14em] text-primary">{eyebrow}</p>
        <h1 className="mt-1 text-2xl font-bold sm:text-3xl">{title}</h1>
        {description && <p className="mt-1.5 max-w-2xl text-sm text-muted-foreground">{description}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}

export function Panel({
  title,
  icon,
  action,
  children,
  className = "",
}: {
  title?: ReactNode;
  icon?: ReactNode;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section className={`rounded-2xl border bg-card shadow-card ${className}`}>
      {title && (
        <div className="flex items-center justify-between gap-3 border-b px-5 py-3.5">
          <h2 className="flex items-center gap-2 text-sm font-semibold">
            {icon}
            {title}
          </h2>
          {action}
        </div>
      )}
      <div className="p-5">{children}</div>
    </section>
  );
}
